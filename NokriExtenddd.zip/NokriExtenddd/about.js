document.addEventListener("DOMContentLoaded", () => {
  const banner = document.getElementById("cookie-consent-banner");
  const acceptBtn = document.getElementById("cookie-accept-btn");
  const declineBtn = document.getElementById("cookie-decline-btn");
  const statusEl = document.getElementById("cookie-consent-status");

  const STORAGE_KEY = "nokriCookieConsent"; // "accepted" | "declined"

  chrome.storage.local.get([STORAGE_KEY], (result) => {
    if (!result[STORAGE_KEY]) {
      banner.classList.add("visible");
    }
  });

  function recordChoice(choice) {
    chrome.storage.local.set({ [STORAGE_KEY]: choice }, () => {
      banner.classList.remove("visible");
      statusEl.textContent = choice === "accepted"
        ? "Thanks — your choice has been saved."
        : "Got it — the extension will keep working normally.";
      statusEl.style.display = "block";
      setTimeout(() => { statusEl.style.display = "none"; }, 4000);
    });
  }

  acceptBtn.addEventListener("click", () => recordChoice("accepted"));
  declineBtn.addEventListener("click", () => recordChoice("declined"));
});