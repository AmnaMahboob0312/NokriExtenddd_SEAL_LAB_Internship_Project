// ===== SCRAPER FUNCTIONS =====

function scrapeJobTitle() {
  const titleLink = document.querySelector('a[href*="/jobs/view/"]');
  return titleLink ? titleLink.textContent.trim() : null;
}

function scrapeCompanyName() {
  const companyLink = document.querySelector('a[href*="/company/"]');
  return companyLink ? companyLink.textContent.trim() : null;
}

function scrapeLocation() {
  const titleLink = document.querySelector('a[href*="/jobs/view/"]');
  if (!titleLink) return null;

  let container = titleLink;
  for (let i = 0; i < 8 && container.parentElement; i++) {
    container = container.parentElement;
  }

  const paragraphs = container.querySelectorAll('p');

  for (const p of paragraphs) {
    const spans = p.querySelectorAll('span');
    const fullText = p.textContent.trim();

    if (spans.length < 2) continue;
    if (fullText.length > 150) continue;

    const firstSpanText = spans[0].textContent.trim();
    if (firstSpanText.length > 0) {
      return firstSpanText;
    }
  }

  return null;
}

function scrapeEmploymentType() {
  const knownTypes = ['Full-time', 'Part-time', 'Contract', 'Temporary', 'Internship', 'Volunteer', 'Other'];
  const allSpans = document.querySelectorAll('span, button');
  for (const el of allSpans) {
    const text = el.textContent.trim();
    if (knownTypes.includes(text)) {
      return text;
    }
  }
  return null;
}

function scrapeJobDescription() {
  const container = document.querySelector('[id^="JobDetails_AboutTheJob_"]');
  if (!container) return null;
  const paragraph = container.querySelector('p');
  return paragraph ? paragraph.textContent.trim() : null;
}

function scrapeCompanyDescription() {
  const container = document.querySelector('[id^="JobDetails_AboutTheCompany_"]');
  if (!container) return null;
  return container.textContent.trim();
}

function scrapeSalary(descriptionText) {
  if (!descriptionText) return null;
  const salaryPattern = /(PKR|Rs\.?|USD|\$|£|€)\s?[\d,]+k?\s?(-|to)?\s?[\d,]*k?/i;
  const match = descriptionText.match(salaryPattern);
  return match ? match[0].trim() : null;
}

function scrapeRequirements(descriptionText) {
  if (!descriptionText) return null;
  const requirementsPattern = /Requirements?:?\s*([\s\S]*?)(?=(Responsibilities|Ready to Apply|About the|$))/i;
  const match = descriptionText.match(requirementsPattern);
  return match ? match[1].trim() : null;
}

function scrapeDepartment() {
  return null;
}

function runFullScrape() {
  const jobDescription = scrapeJobDescription();

  window.__NokriExtendddScrapedData = {
    job_title: scrapeJobTitle(),
    company_name: scrapeCompanyName(),
    company_description: scrapeCompanyDescription(),
    job_description: jobDescription,
    job_requirement: scrapeRequirements(jobDescription),
    salary: scrapeSalary(jobDescription),
    location: scrapeLocation(),
    employment_type: scrapeEmploymentType(),
    department: scrapeDepartment()
  };

  chrome.storage.local.get(["nokriToken", "nokriExpiresAt"], (result) => {
    const token = result.nokriToken;

    if (!token) return;

    if (result.nokriExpiresAt && Date.now() >= result.nokriExpiresAt) return;

    requestScore(window.__NokriExtendddScrapedData, token);
  });
}

// Pulled out into its own function (point 8) so a failed request can be
// retried from the badge itself without re-scraping the page.
function requestScore(scrapedData, token) {
  fetch("http://localhost:3000/score", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${token}`
    },
    body: JSON.stringify(scrapedData)
  })
    .then(response => response.json())
    .then(scoreResult => {
      window.__NokriExtendddScoreResult = scoreResult;
      injectBadge(scrapedData, scoreResult, { failed: false });
    })
    .catch(error => {
      console.error("NokriExtenddd: failed to reach scoring API", error);
      injectBadge(scrapedData, null, { failed: true, token });
    });
}

// ===== JOB ID TRACKING (prevents duplicate/repeated scraping) =====

function getJobIdFromUrl() {
  const match = window.location.href.match(/currentJobId=(\d+)/);
  return match ? match[1] : window.location.href;
}

let lastScrapedJobId = null;

function startWatchingForJob() {
  const jobIdAtStart = getJobIdFromUrl();

  if (jobIdAtStart === lastScrapedJobId) return;

  const observer = new MutationObserver(() => {
    const titleEl = document.querySelector('a[href*="/jobs/view/"]');
    const descContainer = document.querySelector('[id^="JobDetails_AboutTheJob_"]');
    const descParagraph = descContainer ? descContainer.querySelector('p') : null;

    if (titleEl && descParagraph) {
      observer.disconnect();
      setTimeout(() => {
        const currentJobId = getJobIdFromUrl();
        if (currentJobId === lastScrapedJobId) return;
        lastScrapedJobId = currentJobId;
        runFullScrape();
      }, 500);
    }
  });

  observer.observe(document.body, { childList: true, subtree: true });
}

startWatchingForJob();

// ===== RE-RUN WHEN LINKEDIN NAVIGATES TO A DIFFERENT JOB =====

let lastUrl = window.location.href;

const urlWatcher = new MutationObserver(() => {
  if (window.location.href !== lastUrl) {
    lastUrl = window.location.href;
    startWatchingForJob();
  }
});

urlWatcher.observe(document.body, { childList: true, subtree: true });

// ===== RESPOND TO POPUP REQUESTS =====

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "GET_SCRAPED_DATA") {
    sendResponse(window.__NokriExtendddScrapedData || null);
  }
});

// ===== BADGE INJECTOR =====

function injectBadge(data, scoreResult, meta = {}) {
  const existingBadge = document.getElementById("nokri-extenddd-badge");
  if (existingBadge) existingBadge.remove();

  const quotaReached = scoreResult && scoreResult.quotaReached;
  const trustScore = (scoreResult && !quotaReached) ? (100 - scoreResult.score) : null;

  let statusColor, statusLabel;
  if (quotaReached) {
    statusColor = "#B24020";
    statusLabel = "QUOTA REACHED";
  } else if (meta.failed) {
    statusColor = "#666666";
    statusLabel = "Unavailable";
  } else if (trustScore === null) {
    statusColor = "#666666";
    statusLabel = "Unavailable";
  } else if (trustScore >= 70) {
    statusColor = "#057642";
    statusLabel = "Likely Real";
  } else if (trustScore >= 40) {
    statusColor = "#B8860B";
    statusLabel = "Use Caution";
  } else {
    statusColor = "#CC1016";
    statusLabel = "Likely Fake";
  }

  if (!document.getElementById("nokri-extenddd-style")) {
    const style = document.createElement("style");
    style.id = "nokri-extenddd-style";
    style.textContent = `
      @keyframes nokriSlideIn {
        from { opacity: 0; transform: translateY(-8px); }
        to { opacity: 1; transform: translateY(0); }
      }
      @media (prefers-reduced-motion: reduce) {
        #nokri-extenddd-badge { animation: none !important; }
      }
      #nokri-extenddd-badge {
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
        font-size: 1.3125rem; /* bumped again — still not readable enough at 1.125rem */
      }
      #nokri-extenddd-badge * { box-sizing: border-box; }
      .nokri-logo-badge {
        width: 3rem;
        height: 3rem;
        background: #0A66C2;
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #ffffff;
        font-weight: 800;
        font-size: 1.0625rem;
        letter-spacing: -0.5px;
        transition: background 0.15s ease;
      }
      .nokri-logo-badge:hover { background: #004182; }

      /* ===== ACCESSIBILITY: visible focus indicators ===== */
      #nokri-extenddd-badge button:focus-visible {
        outline: 3px solid #57A3F5;
        outline-offset: 2px;
      }
      #nokri-extenddd-badge button:focus {
        outline: 2px solid #0A66C2;
        outline-offset: 1px;
      }
      .nokri-retry-btn {
        margin-top: 0.625rem;
        width: 100%;
        padding: 0.5rem;
        font-size: 0.9375rem;
        border: 1px solid #CC1016;
        border-radius: 14px;
        background: #ffffff;
        color: #CC1016;
        cursor: pointer;
      }
      .nokri-retry-btn:hover { background: #FDECEC; }
    `;
    document.head.appendChild(style);
  }

  const badge = document.createElement("div");
  badge.id = "nokri-extenddd-badge";
  badge.setAttribute("role", "region");
  badge.setAttribute("aria-label", "NokriExtenddd job trust score");
  badge.style.cssText = `
    position: fixed;
    top: 80px;
    right: 20px;
    background: #ffffff;
    border: 1px solid #E0E0E0;
    border-radius: 10px;
    padding: 1.625rem;
    color: #000000E6;
    box-shadow: 0 6px 18px rgba(0,0,0,0.18);
    z-index: 9999;
    width: 380px;
    max-width: 92vw;
    animation: nokriSlideIn 0.25s ease-out;
  `;

  let scoreDisplay;
  if (quotaReached) {
    scoreDisplay = `<div style="font-size: 1.0625rem; color: ${statusColor}; font-weight: 600;">${scoreResult.error}</div>`;
  } else if (meta.failed) {
    // ===== ERROR STATE WITH RECOVERY =====
    scoreDisplay = `<div style="color: #555; font-size: 1.0625rem;">Couldn't reach the scoring service. Is the server running?</div>`;
  } else if (trustScore === null) {
    scoreDisplay = `<div style="color: #555; font-size: 1.0625rem;">Scoring unavailable</div>`;
  } else {
    scoreDisplay = `
      <div style="display: flex; align-items: baseline; gap: 0.75rem; margin: 0.875rem 0 0.625rem 0;">
        <span style="font-size: 3.25rem; font-weight: 700; color: ${statusColor}; line-height: 1;">${trustScore}%</span>
        <span style="
          font-size: 1rem;
          font-weight: 600;
          color: #ffffff;
          background: ${statusColor};
          padding: 5px 12px;
          border-radius: 12px;
        ">${statusLabel}</span>
      </div>
    `;
    if (scoreResult.flags && scoreResult.flags.length > 0) {
      scoreDisplay += `<ul style="margin: 0.875rem 0 0 1.25rem; padding: 0; font-size: 1.0625rem; color: #444; line-height: 1.6;">`;
      scoreResult.flags.forEach(flag => {
        scoreDisplay += `<li>${flag}</li>`;
      });
      scoreDisplay += `</ul>`;
    }
  }

  let prefWarning = "";
  if (scoreResult && scoreResult.preferenceMatch && scoreResult.preferenceMatch.checked && !scoreResult.preferenceMatch.matches) {
    prefWarning = `
      <div style="margin-top:0.875rem; padding:0.75rem 0.875rem; background:#FFF8E6; border-left:4px solid #B8860B; border-radius:4px; font-size:1rem; color:#6B4F00;">
        <strong>Doesn't match your preferences:</strong>
        <ul style="margin:0.375rem 0 0 1.125rem; padding:0;">
          ${scoreResult.preferenceMatch.mismatches.map(m => `<li>${m}</li>`).join('')}
        </ul>
      </div>
    `;
  }

  badge.innerHTML = `
    <div style="display: flex; align-items: center; gap: 0.875rem; margin-bottom: 0.875rem; padding-bottom: 0.875rem; border-bottom: 1px solid #E0E0E0;">
      <div class="nokri-logo-badge" aria-hidden="true">eXD</div>
      <span style="font-weight: 700; font-size: 1.25rem; color: #000000E6;">NokriExtenddd</span>
    </div>
    <div style="font-size: 1.3125rem; font-weight: 700; color: #000000E6; line-height: 1.3;">${data.job_title || "Unknown title"}</div>
    <div style="font-size: 1.0625rem; color: #555; margin-bottom: 4px; margin-top: 3px;">${data.company_name || "Unknown company"}</div>
    ${scoreDisplay}
    ${prefWarning}
    ${meta.failed ? `<button type="button" class="nokri-retry-btn" id="nokri-retry-score-btn">Retry</button>` : ''}
    <div style="display: flex; gap: 0.625rem; margin-top: 1rem;">
      <button type="button" id="nokri-log-saved" style="flex:1; padding: 0.6875rem; font-size: 1.0625rem; font-weight: 600; border: 1px solid #D0D0D0; border-radius: 18px; background: #fff; cursor: pointer;">Save</button>
      <button type="button" id="nokri-log-applied" style="flex:1; padding: 0.6875rem; font-size: 1.0625rem; font-weight: 600; border: 1px solid #D0D0D0; border-radius: 18px; background: #fff; cursor: pointer;">Applied</button>
    </div>
  `;

  document.body.appendChild(badge);

  if (meta.failed) {
    document.getElementById("nokri-retry-score-btn").addEventListener("click", () => {
      requestScore(data, meta.token);
    });
  }

  function logAction(action, button) {
    chrome.storage.local.get(["nokriToken", "nokriExpiresAt"], (result) => {
      const token = result.nokriToken;
      if (!token) {
        console.error("NokriExtenddd: no auth token found");
        return;
      }

      if (result.nokriExpiresAt && Date.now() >= result.nokriExpiresAt) {
        alert("Your NokriExtenddd session has expired. Please reopen the extension popup and log in again.");
        return;
      }

      const originalText = button.textContent;
      button.disabled = true;
      button.textContent = "...";

      fetch("http://localhost:3000/log-action", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({
          job_title: data.job_title,
          company_name: data.company_name,
          action: action
        })
      })
        .then((res) => {
          if (res.status === 401) {
            alert("Your NokriExtenddd session has expired. Please reopen the extension popup and log in again.");
            throw new Error("Session expired");
          }
          if (!res.ok) throw new Error(`Server responded ${res.status}`);
          button.textContent = "✓ " + originalText;
          button.style.background = "#e6f4ea";
          button.style.borderColor = "#34a853";
        })
        .catch((err) => {
          console.error("NokriExtenddd: log-action failed", err);
          button.disabled = false;
          button.textContent = originalText;
        });
    });
  }

  document.getElementById("nokri-log-saved").addEventListener("click", function () {
    if (window.confirm(`Save "${data.job_title || 'this job'}" for later?`)) {
      logAction("saved", this);
    }
  });
  document.getElementById("nokri-log-applied").addEventListener("click", function () {
    if (window.confirm(`Mark "${data.job_title || 'this job'}" as applied?`)) {
      logAction("applied", this);
    }
  });
}