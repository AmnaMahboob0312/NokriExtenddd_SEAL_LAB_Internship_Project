// ===== SCRAPER FUNCTIONS =====

function scrapeJobTitle() {
  const titleLink = document.querySelector('a[href*="/jobs/view/"]');
  return titleLink ? titleLink.textContent.trim() : null;
}

function scrapeCompanyName() {
  const companyLink = document.querySelector('a[href*="/company/"]');
  return companyLink ? companyLink.textContent.trim() : null;
}

function scrapeLocation() {
  const titleLink = document.querySelector('a[href*="/jobs/view/"]');
  if (!titleLink) return null;

  // Widen out from the title to a reasonably-sized container, then check
  // every <p> in it — not just the first one — for the shape we want:
  // a short paragraph made of 2+ <span> children (job descriptions are
  // long single blocks of text, not short multi-span lines).
  let container = titleLink;
  for (let i = 0; i < 8 && container.parentElement; i++) {
    container = container.parentElement;
  }

  const paragraphs = container.querySelectorAll('p');

  for (const p of paragraphs) {
    const spans = p.querySelectorAll('span');
    const fullText = p.textContent.trim();

    console.log("NokriExtenddd DEBUG: candidate <p>, spans:", spans.length, "length:", fullText.length, "text:", fullText.slice(0, 60));

    if (spans.length < 2) continue;
    if (fullText.length > 150) continue; // job descriptions are much longer than a metadata line

    const firstSpanText = spans[0].textContent.trim();
    if (firstSpanText.length > 0) {
      return firstSpanText;
    }
  }

  return null;
}

function scrapeEmploymentType() {
  const knownTypes = ['Full-time', 'Part-time', 'Contract', 'Temporary', 'Internship', 'Volunteer', 'Other'];
  const allSpans = document.querySelectorAll('span, button');
  for (const el of allSpans) {
    const text = el.textContent.trim();
    if (knownTypes.includes(text)) {
      return text;
    }
  }
  return null;
}

function scrapeJobDescription() {
  const container = document.querySelector('[id^="JobDetails_AboutTheJob_"]');
  if (!container) return null;
  const paragraph = container.querySelector('p');
  return paragraph ? paragraph.textContent.trim() : null;
}

function scrapeCompanyDescription() {
  const container = document.querySelector('[id^="JobDetails_AboutTheCompany_"]');
  if (!container) return null;
  return container.textContent.trim();
}

function scrapeSalary(descriptionText) {
  if (!descriptionText) return null;
  const salaryPattern = /(PKR|Rs\.?|USD|\$|£|€)\s?[\d,]+k?\s?(-|to)?\s?[\d,]*k?/i;
  const match = descriptionText.match(salaryPattern);
  return match ? match[0].trim() : null;
}

function scrapeRequirements(descriptionText) {
  if (!descriptionText) return null;
  const requirementsPattern = /Requirements?:?\s*([\s\S]*?)(?=(Responsibilities|Ready to Apply|About the|$))/i;
  const match = descriptionText.match(requirementsPattern);
  return match ? match[1].trim() : null;
}

function scrapeDepartment() {
  return null;
}

function runFullScrape() {
  const jobDescription = scrapeJobDescription();

  window.__NokriExtendddScrapedData = {
    job_title: scrapeJobTitle(),
    company_name: scrapeCompanyName(),
    company_description: scrapeCompanyDescription(),
    job_description: jobDescription,
    job_requirement: scrapeRequirements(jobDescription),
    salary: scrapeSalary(jobDescription),
    location: scrapeLocation(),
    employment_type: scrapeEmploymentType(),
    department: scrapeDepartment()
  };

  console.log("NokriExtenddd scrape result:", window.__NokriExtendddScrapedData);

  chrome.storage.local.get(["nokriToken"], (result) => {
    const token = result.nokriToken;

    if (!token) {
      console.log("NokriExtenddd: not logged in, skipping score request");
      return;
    }

    fetch("http://localhost:3000/score", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`
      },
      body: JSON.stringify(window.__NokriExtendddScrapedData)
    })
      .then(response => response.json())
      .then(scoreResult => {
        console.log("NokriExtenddd score result:", scoreResult);
        window.__NokriExtendddScoreResult = scoreResult;
        injectBadge(window.__NokriExtendddScrapedData, scoreResult);
      })
      .catch(error => {
        console.error("NokriExtenddd: failed to reach scoring API", error);
        injectBadge(window.__NokriExtendddScrapedData, null);
      });
  });
}

// ===== JOB ID TRACKING (prevents duplicate/repeated scraping) =====

function getJobIdFromUrl() {
  const match = window.location.href.match(/currentJobId=(\d+)/);
  return match ? match[1] : window.location.href;
}

let lastScrapedJobId = null;

function startWatchingForJob() {
  const jobIdAtStart = getJobIdFromUrl();

  if (jobIdAtStart === lastScrapedJobId) return;

  const observer = new MutationObserver(() => {
    const titleEl = document.querySelector('a[href*="/jobs/view/"]');
    const descContainer = document.querySelector('[id^="JobDetails_AboutTheJob_"]');
    const descParagraph = descContainer ? descContainer.querySelector('p') : null;

    if (titleEl && descParagraph) {
      observer.disconnect();
      setTimeout(() => {
        const currentJobId = getJobIdFromUrl();
        if (currentJobId === lastScrapedJobId) return;
        lastScrapedJobId = currentJobId;
        runFullScrape();
      }, 500);
    }
  });

  observer.observe(document.body, { childList: true, subtree: true });
}

console.log("Fake Job Detector: content script injected on", window.location.href);
startWatchingForJob();

// ===== RE-RUN WHEN LINKEDIN NAVIGATES TO A DIFFERENT JOB =====

let lastUrl = window.location.href;

const urlWatcher = new MutationObserver(() => {
  if (window.location.href !== lastUrl) {
    lastUrl = window.location.href;
    console.log("NokriExtenddd: detected job navigation, re-scraping...");
    startWatchingForJob();
  }
});

urlWatcher.observe(document.body, { childList: true, subtree: true });

// ===== RESPOND TO POPUP REQUESTS =====

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "GET_SCRAPED_DATA") {
    sendResponse(window.__NokriExtendddScrapedData || null);
  }
});

// ===== BADGE INJECTOR =====

function injectBadge(data, scoreResult) {
  const existingBadge = document.getElementById("nokri-extenddd-badge");
  if (existingBadge) existingBadge.remove();

  const quotaReached = scoreResult && scoreResult.quotaReached;
  const trustScore = (scoreResult && !quotaReached) ? (100 - scoreResult.score) : null;

  let statusColor, statusLabel;
  if (quotaReached) {
    statusColor = "#B24020";
    statusLabel = "QUOTA REACHED";
  } else if (trustScore === null) {
    statusColor = "#666666";
    statusLabel = "Unavailable";
  } else if (trustScore >= 70) {
    statusColor = "#057642";
    statusLabel = "Likely Real";
  } else if (trustScore >= 40) {
    statusColor = "#B8860B";
    statusLabel = "Use Caution";
  } else {
    statusColor = "#CC1016";
    statusLabel = "Likely Fake";
  }

  if (!document.getElementById("nokri-extenddd-style")) {
    const style = document.createElement("style");
    style.id = "nokri-extenddd-style";
    style.textContent = `
      @keyframes nokriSlideIn {
        from { opacity: 0; transform: translateY(-8px); }
        to { opacity: 1; transform: translateY(0); }
      }
      #nokri-extenddd-badge {
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
      }
      #nokri-extenddd-badge * { box-sizing: border-box; }
      .nokri-logo-badge {
        width: 32px;
        height: 32px;
        background: #0A66C2;
        border-radius: 6px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #ffffff;
        font-weight: 800;
        font-size: 13px;
        letter-spacing: -0.5px;
        transition: background 0.15s ease;
      }
      .nokri-logo-badge:hover { background: #004182; }
    `;
    document.head.appendChild(style);
  }

  const badge = document.createElement("div");
  badge.id = "nokri-extenddd-badge";
  badge.style.cssText = `
    position: fixed;
    top: 80px;
    right: 20px;
    background: #ffffff;
    border: 1px solid #E0E0E0;
    border-radius: 8px;
    padding: 16px;
    color: #000000E6;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    z-index: 9999;
    max-width: 280px;
    animation: nokriSlideIn 0.25s ease-out;
  `;

  let scoreDisplay;
  if (quotaReached) {
    scoreDisplay = `<div style="font-size: 12px; color: ${statusColor}; font-weight: 600;">${scoreResult.error}</div>`;
  } else if (trustScore === null) {
    scoreDisplay = `<div style="color: #666; font-size: 13px;">Scoring unavailable</div>`;
  } else {
    scoreDisplay = `
      <div style="display: flex; align-items: baseline; gap: 8px; margin: 8px 0 4px 0;">
        <span style="font-size: 30px; font-weight: 700; color: ${statusColor};">${trustScore}%</span>
        <span style="
          font-size: 11px;
          font-weight: 600;
          color: #ffffff;
          background: ${statusColor};
          padding: 3px 8px;
          border-radius: 12px;
        ">${statusLabel}</span>
      </div>
    `;
    if (scoreResult.flags && scoreResult.flags.length > 0) {
      scoreDisplay += `<ul style="margin: 10px 0 0 16px; padding: 0; font-size: 12px; color: #555; line-height: 1.5;">`;
      scoreResult.flags.forEach(flag => {
        scoreDisplay += `<li>${flag}</li>`;
      });
      scoreDisplay += `</ul>`;
    }
  }

  let prefWarning = "";
if (scoreResult && scoreResult.preferenceMatch && scoreResult.preferenceMatch.checked && !scoreResult.preferenceMatch.matches) {
  prefWarning = `
    <div style="margin-top:10px; padding:8px 10px; background:#FFF8E6; border-left:3px solid #B8860B; border-radius:4px; font-size:11px; color:#7A5C00;">
      <strong>Doesn't match your preferences:</strong>
      <ul style="margin:4px 0 0 14px; padding:0;">
        ${scoreResult.preferenceMatch.mismatches.map(m => `<li>${m}</li>`).join('')}
      </ul>
    </div>
  `;
}

 badge.innerHTML = `
  <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; padding-bottom: 10px; border-bottom: 1px solid #E0E0E0;">
    <div class="nokri-logo-badge">eXD</div>
    <span style="font-weight: 700; font-size: 14px; color: #000000E6;">NokriExtenddd</span>
  </div>
  <div style="font-size: 14px; font-weight: 600; color: #000000E6;">${data.job_title || "Unknown title"}</div>
  <div style="font-size: 12px; color: #666; margin-bottom: 2px;">${data.company_name || "Unknown company"}</div>
  ${scoreDisplay}
  ${prefWarning}
  <div style="display: flex; gap: 6px; margin-top: 10px;">
    <button id="nokri-log-saved" style="flex:1; padding: 6px; font-size: 11px; border: 1px solid #E0E0E0; border-radius: 14px; background: #fff; cursor: pointer;">Save</button>
    <button id="nokri-log-applied" style="flex:1; padding: 6px; font-size: 11px; border: 1px solid #E0E0E0; border-radius: 14px; background: #fff; cursor: pointer;">Applied</button>
  </div>
`;

  document.body.appendChild(badge);

  function logAction(action, button) {
    chrome.storage.local.get(["nokriToken"], (result) => {
      const token = result.nokriToken;
      if (!token) {
        console.error("NokriExtenddd: no auth token found");
        return;
      }

      const originalText = button.textContent;
      button.disabled = true;
      button.textContent = "...";

      fetch("http://localhost:3000/log-action", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({
          job_title: data.job_title,
          company_name: data.company_name,
          action: action
        })
      })
      .then((res) => {
        if (!res.ok) throw new Error(`Server responded ${res.status}`);
        console.log(`NokriExtenddd: logged "${action}"`);
        button.textContent = "✓ " + originalText;
        button.style.background = "#e6f4ea";
        button.style.borderColor = "#34a853";
      })
      .catch((err) => {
        console.error("NokriExtenddd: log-action failed", err);
        button.disabled = false;
        button.textContent = originalText;
      });
    });
  }

  document.getElementById("nokri-log-saved").addEventListener("click", function () { logAction("saved", this); });
document.getElementById("nokri-log-applied").addEventListener("click", function () { logAction("applied", this); });
}