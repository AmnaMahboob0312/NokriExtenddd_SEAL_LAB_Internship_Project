document.addEventListener("DOMContentLoaded", () => {
  const contentDiv = document.getElementById("dashboard-content");
  const prefStatus = document.getElementById("preferences-status");
  const savedJobsStatus = document.getElementById("saved-jobs-status");
  let currentPlan = 'free';
  let fullHistory = [];
  let appliedKeys = new Set();
  let savedKeys = new Set();

  const HISTORY_COLLAPSE_LIMIT = 5;
  let historyExpanded = false;

  function activityKey(jobTitle, companyName) {
    return `${(jobTitle || "").trim().toLowerCase()}|${(companyName || "").trim().toLowerCase()}`;
  }

  // ===== ERROR STATES WITH RECOVERY (point 8) =====
  //
  // Renders a plain-language message plus a Retry button inside the given
  // container, wired to re-run whatever load function failed. Used for
  // every independent section on this page (main dashboard, preferences,
  // saved jobs, activity) so one section failing never leaves a dead end —
  // and never wipes out a sibling section that loaded fine.
  function renderSectionError(container, message, retryFn) {
    container.innerHTML = "";
    const wrapper = document.createElement("div");
    wrapper.className = "section-error";
    wrapper.setAttribute("role", "alert");

    const p = document.createElement("p");
    p.textContent = message;

    const retryBtn = document.createElement("button");
    retryBtn.type = "button";
    retryBtn.className = "retry-btn";
    retryBtn.textContent = "Retry";
    retryBtn.addEventListener("click", retryFn);

    wrapper.appendChild(p);
    wrapper.appendChild(retryBtn);
    container.appendChild(wrapper);
  }

  // ===== SESSION HANDLING =====

  function showSessionExpiredState(message) {
    chrome.storage.local.remove(["nokriToken", "nokriEmail", "nokriExpiresAt"]);
    const notice = `<p style="color:#CC1016;">${message || "Your session has expired."} Please reopen the extension popup and log in again.</p>`;
    contentDiv.innerHTML = notice;
    document.querySelectorAll(".nokri-card").forEach((card) => {
      if (card.id !== "dashboard-content") card.style.display = "none";
    });
  }

  function handleIfSessionExpired(response, data) {
    if (response.status === 401) {
      showSessionExpiredState(data && data.error);
      return true;
    }
    return false;
  }

  let cachedToken = null;

  function loadDashboard(token) {
    fetch("http://localhost:3000/dashboard", {
      headers: { "Authorization": `Bearer ${token}` }
    })
      .then(async (response) => {
        const data = await response.json();
        if (handleIfSessionExpired(response, data)) return;

        if (!response.ok) {
          renderSectionError(contentDiv, data.error || "Could not load your dashboard.", () => loadDashboard(token));
          return;
        }

        currentPlan = data.plan;

        if (data.plan === 'free') {
          renderFreeStats(data.stats);
        } else {
          fullHistory = data.history;
          historyExpanded = false;
          renderHistoryTable('all');
        }
      })
      .catch(() => {
        renderSectionError(contentDiv, "Could not reach the server. Is it running?", () => loadDashboard(token));
      });
  }

  chrome.storage.local.get(["nokriToken", "nokriExpiresAt"], (result) => {
    const token = result.nokriToken;
    cachedToken = token;

    if (!token) {
      contentDiv.innerHTML = `<p>Please log in through the extension popup first.</p>`;
      document.getElementById("preferences-form-wrapper")?.remove();
      return;
    }

    if (result.nokriExpiresAt && Date.now() >= result.nokriExpiresAt) {
      showSessionExpiredState("Your session has expired.");
      return;
    }

    loadDashboard(token);
    loadPreferences(token);
    loadSavedJobs(token);
    loadActivity(token);
  });

  function renderFreeStats(stats) {
    contentDiv.innerHTML = `
      <div class="stat-row">
        <div class="stat-box" style="background: #F0F5FB;">
          <div class="stat-number" style="color: #0A66C2;">${stats.total_screenings}</div>
          <div class="stat-label">Total Screenings</div>
        </div>
        <div class="stat-box" style="background: #FDECEC;">
          <div class="stat-number" style="color: #CC1016;">${stats.high_risk_count}</div>
          <div class="stat-label">Likely Fake</div>
        </div>
        <div class="stat-box" style="background: #FFF8E6;">
          <div class="stat-number" style="color: #B8860B;">${stats.caution_count}</div>
          <div class="stat-label">Use Caution</div>
        </div>
        <div class="stat-box" style="background: #E9F7EF;">
          <div class="stat-number" style="color: #057642;">${stats.likely_real_count}</div>
          <div class="stat-label">Likely Real</div>
        </div>
      </div>
      <p class="upgrade-note">Upgrade to Pro to see your full per-job screening history.</p>
    `;
  }

  function categorize(item) {
    if (item.score >= 60) return 'fake';
    if (item.score >= 30) return 'caution';
    return 'real';
  }

  function renderHistoryTable(filter) {
    if (fullHistory.length === 0) {
      contentDiv.innerHTML = `<p>No screenings yet — start browsing LinkedIn jobs to see your history here.</p>`;
      return;
    }

    const filtered = fullHistory.filter(item => {
      const key = activityKey(item.job_title, item.company_name);
      switch (filter) {
        case 'real': return categorize(item) === 'real';
        case 'caution': return categorize(item) === 'caution';
        case 'fake': return categorize(item) === 'fake';
        case 'applied': return appliedKeys.has(key);
        case 'saved': return savedKeys.has(key);
        default: return true;
      }
    });

    const visibleRows = historyExpanded ? filtered : filtered.slice(0, HISTORY_COLLAPSE_LIMIT);

    const rowHtml = (item) => {
      const category = categorize(item);
      const key = activityKey(item.job_title, item.company_name);
      const rowClass = `history-row-${category}`;

      const badges = [];
      if (appliedKeys.has(key)) {
        badges.push(`<span class="status-badge applied">✓ Applied</span>`);
      }
      if (savedKeys.has(key)) {
        badges.push(`<span class="status-badge saved">⏳ Saved</span>`);
      }
      const badgeHtml = badges.length
        ? `<div class="status-badge-row">${badges.join('')}</div>`
        : `<span style="color:#999; font-size:0.6875rem;">—</span>`;

      return `
        <tr class="${rowClass}">
          <td>${item.job_title}</td>
          <td>${item.company_name}</td>
          <td>${item.score}</td>
          <td>${new Date(item.created_at).toLocaleDateString()}</td>
          <td>${badgeHtml}</td>
        </tr>
      `;
    };

    const rows = visibleRows.map(rowHtml).join('');

    const emptyMessage = filtered.length === 0
      ? `<p style="font-size:0.8125rem;color:#666;">No screenings match this filter.</p>`
      : `<div class="history-table-wrapper">
          <table>
            <thead>
              <tr><th>Job Title</th><th>Company</th><th>Fraud Score</th><th>Date</th><th>Status</th></tr>
            </thead>
            <tbody>${rows}</tbody>
          </table>
        </div>`;

    const needsToggle = filtered.length > HISTORY_COLLAPSE_LIMIT;
    const toggleHtml = needsToggle
      ? `<div class="history-toggle-row">
          <button id="history-toggle-btn">
            ${historyExpanded ? "Show fewer" : `Show all ${filtered.length} screenings`}
          </button>
        </div>`
      : '';

    contentDiv.innerHTML = `
      <label for="history-filter" style="position:absolute;width:1px;height:1px;overflow:hidden;">Filter screening history</label>
      <select id="history-filter">
        <option value="all" ${filter === 'all' ? 'selected' : ''}>All Screenings (${fullHistory.length})</option>
        <option value="real" ${filter === 'real' ? 'selected' : ''}>Likely Real</option>
        <option value="caution" ${filter === 'caution' ? 'selected' : ''}>Use Caution</option>
        <option value="fake" ${filter === 'fake' ? 'selected' : ''}>Likely Fake</option>
        <option value="applied" ${filter === 'applied' ? 'selected' : ''}>Applied</option>
        <option value="saved" ${filter === 'saved' ? 'selected' : ''}>Saved</option>
      </select>
      ${emptyMessage}
      ${toggleHtml}
    `;

    document.getElementById("history-filter").addEventListener("change", (e) => {
      historyExpanded = false;
      renderHistoryTable(e.target.value);
    });

    const toggleBtn = document.getElementById("history-toggle-btn");
    if (toggleBtn) {
      toggleBtn.addEventListener("click", () => {
        historyExpanded = !historyExpanded;
        const currentFilterEl = document.getElementById("history-filter");
        renderHistoryTable(currentFilterEl ? currentFilterEl.value : 'all');
      });
    }
  }

  // ===== PREFERENCES (single add/edit slot + view-all list) =====

  const formContainer = document.getElementById("preference-form-container");
  const limitNote = document.getElementById("preferences-limit-note");
  const viewBtn = document.getElementById("view-preferences-btn");
  const listDiv = document.getElementById("preferences-list");
  const formTemplate = document.getElementById("pref-form-template");
  const summaryTemplate = document.getElementById("pref-summary-template");

  let allProfiles = [];
  let editingId = null;

  // Point 7 (preserve entered data on error): while a save/add/edit is in
  // flight, whatever the person typed lives in these fields; renderForm()
  // below is only ever called with fresh server data (a successful load or
  // save), never as a side effect of an error — so a failed save leaves the
  // exact same values in the form for another attempt.

  async function loadPreferences(token) {
    try {
      const response = await fetch("http://localhost:3000/preferences", {
        headers: { "Authorization": `Bearer ${token}` }
      });
      const data = await response.json();

      if (handleIfSessionExpired(response, data)) return;

      if (!response.ok) {
        renderSectionError(formContainer, "Could not load your preferences.", () => loadPreferences(token));
        return;
      }

      allProfiles = data.preferences;
      editingId = null;
      renderForm(token);
    } catch (err) {
      renderSectionError(formContainer, "Could not reach the server to load preferences.", () => loadPreferences(token));
    }
  }

  function renderForm(token) {
    const maxAllowed = currentPlan === 'free' ? 1 : 10;
    limitNote.textContent = `${allProfiles.length} of ${maxAllowed} preference${maxAllowed > 1 ? 's' : ''} used`;

    const atLimit = allProfiles.length >= maxAllowed && editingId === null;

    if (atLimit) {
      formContainer.innerHTML = currentPlan === 'free'
        ? `<p style="font-size:0.8125rem;color:#B8860B;">You've used your 1 free preference. Upgrade to Pro to add up to 10.</p>`
        : `<p style="font-size:0.8125rem;color:#B8860B;">You've reached the maximum of 10 preferences.</p>`;
      return;
    }

    formContainer.innerHTML = "";
    const form = formTemplate.content.cloneNode(true);

    const editingProfile = editingId ? allProfiles.find(p => p.id === editingId) : null;
    if (editingProfile) {
      form.querySelector(".pf-label").value = editingProfile.label || "";
      form.querySelector(".pf-department").value = editingProfile.preferred_department || "";
      form.querySelector(".pf-employment-type").value = editingProfile.preferred_employment_type || "";
      form.querySelector(".pf-location").value = editingProfile.preferred_location || "";
      form.querySelector(".pf-min-salary").value = editingProfile.min_salary != null ? editingProfile.min_salary : "";
    }

    formContainer.appendChild(form);
    document.getElementById("save-preferences-btn").addEventListener("click", () => saveCurrentForm(token));
  }

  async function saveCurrentForm(token) {
    const labelEl = formContainer.querySelector(".pf-label");
    if (!labelEl) {
      prefStatus.textContent = "Form isn't available right now — try reopening it.";
      prefStatus.className = "error";
      return;
    }

    const label = labelEl.value.trim();
    const preferred_department = formContainer.querySelector(".pf-department").value.trim();
    const preferred_employment_type = formContainer.querySelector(".pf-employment-type").value.trim();
    const preferred_location = formContainer.querySelector(".pf-location").value.trim();
    const minSalaryRaw = formContainer.querySelector(".pf-min-salary").value.trim();
    const min_salary = minSalaryRaw ? parseFloat(minSalaryRaw) : null;

    const body = {
      label: label || null,
      preferred_department: preferred_department || null,
      preferred_employment_type: preferred_employment_type || null,
      preferred_location: preferred_location || null,
      min_salary
    };

    const confirmMessage = editingId
      ? "Save changes to this preference profile?"
      : "Add this new preference profile?";
    if (!window.confirm(confirmMessage)) {
      prefStatus.textContent = "";
      prefStatus.className = "";
      return;
    }

    prefStatus.textContent = "Saving...";
    prefStatus.className = "";

    try {
      const url = editingId
        ? `http://localhost:3000/preferences/${editingId}`
        : `http://localhost:3000/preferences`;
      const method = editingId ? "PUT" : "POST";

      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify(body)
      });
      const data = await response.json();

      if (handleIfSessionExpired(response, data)) return;

      if (!response.ok) {
        // Point 7: the form itself (formContainer) is left completely
        // untouched here — only the status line changes — so the person's
        // typed values are still there to fix and resubmit.
        prefStatus.textContent = data.error || "Failed to save.";
        prefStatus.className = "error";
        return;
      }

      prefStatus.textContent = "Saved.";
      prefStatus.className = "success";
      loadPreferences(token);
      if (listDiv.style.display !== "none") renderList(token);
    } catch (err) {
      console.error("Save preference failed:", err);
      // Point 7 + 8: form values stay put; the status line gets a message
      // plus an inline Retry that resubmits the same (still-intact) form.
      prefStatus.innerHTML = "";
      const msg = document.createElement("span");
      msg.textContent = "Could not reach the server. ";
      const retryBtn = document.createElement("button");
      retryBtn.type = "button";
      retryBtn.className = "retry-btn";
      retryBtn.textContent = "Retry";
      retryBtn.style.marginLeft = "6px";
      retryBtn.addEventListener("click", () => saveCurrentForm(token));
      prefStatus.className = "error";
      prefStatus.appendChild(msg);
      prefStatus.appendChild(retryBtn);
    }
  }

  function renderList(token) {
    listDiv.innerHTML = "";

    if (allProfiles.length === 0) {
      listDiv.innerHTML = `<p style="font-size:0.8125rem;color:#666;">No preferences saved yet.</p>`;
      return;
    }

    allProfiles.forEach(profile => {
      const row = summaryTemplate.content.cloneNode(true);
      const parts = [
        profile.label ? `<strong>${profile.label}</strong>` : null,
        profile.preferred_department,
        profile.preferred_employment_type,
        profile.preferred_location,
        profile.min_salary != null ? `Min $${profile.min_salary}` : null
      ].filter(Boolean);

      row.querySelector(".pf-summary-text").innerHTML = parts.join(" &middot; ") || "<em>Empty profile</em>";

      row.querySelector(".pf-edit-btn").addEventListener("click", () => {
        editingId = profile.id;
        renderForm(token);
        window.scrollTo({ top: formContainer.offsetTop - 20, behavior: "smooth" });
      });

      row.querySelector(".pf-delete-btn").addEventListener("click", async () => {
        const label = profile.label ? `"${profile.label}"` : "this preference profile";
        if (!window.confirm(`Delete ${label}? This can't be undone.`)) return;

        prefStatus.textContent = "Removing...";
        prefStatus.className = "";
        try {
          const response = await fetch(`http://localhost:3000/preferences/${profile.id}`, {
            method: "DELETE",
            headers: { "Authorization": `Bearer ${token}` }
          });
          const data = await response.json();
          if (handleIfSessionExpired(response, data)) return;
          if (!response.ok) {
            prefStatus.textContent = data.error || "Failed to remove.";
            prefStatus.className = "error";
            return;
          }
          prefStatus.textContent = "Removed.";
          prefStatus.className = "success";
          if (editingId === profile.id) editingId = null;
          loadPreferences(token);
          renderList(token);
        } catch (err) {
          prefStatus.textContent = "Could not reach the server.";
          prefStatus.className = "error";
        }
      });

      listDiv.appendChild(row);
    });
  }

  viewBtn.addEventListener("click", () => {
    chrome.storage.local.get(["nokriToken"], (result) => {
      const token = result.nokriToken;
      const isHidden = listDiv.style.display === "none";
      listDiv.style.display = isHidden ? "block" : "none";
      viewBtn.textContent = isHidden ? "Hide Saved Preferences" : "View Saved Preferences";
      if (isHidden) renderList(token);
    });
  });

  // ===== SAVED JOBS (list, set/edit deadline, remove) =====

  const savedJobsContentDiv = document.getElementById("saved-jobs-content");

  function daysUntil(dateStr) {
    const target = new Date(dateStr + "T00:00:00");
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const diffMs = target.getTime() - today.getTime();
    return Math.round(diffMs / (1000 * 60 * 60 * 24));
  }

  async function loadSavedJobs(token) {
    try {
      const response = await fetch("http://localhost:3000/saved-jobs", {
        headers: { "Authorization": `Bearer ${token}` }
      });
      const data = await response.json();

      if (handleIfSessionExpired(response, data)) return;

      if (!response.ok) {
        renderSectionError(savedJobsContentDiv, "Could not load saved jobs.", () => loadSavedJobs(token));
        return;
      }

      renderSavedJobs(data.savedJobs || [], token);
    } catch (err) {
      renderSectionError(savedJobsContentDiv, "Could not reach the server to load saved jobs.", () => loadSavedJobs(token));
    }
  }

  function renderSavedJobs(jobs, token) {
    if (jobs.length === 0) {
      savedJobsContentDiv.innerHTML = `<p style="font-size:0.8125rem;color:#666;">No saved jobs yet — use the Save button on a LinkedIn posting to add one here.</p>`;
      return;
    }

    savedJobsContentDiv.innerHTML = "";

    jobs.forEach((job) => {
      const daysLeft = job.deadline ? daysUntil(job.deadline) : null;
      const isSoon = daysLeft !== null && daysLeft >= 0 && daysLeft <= 2;

      const row = document.createElement("div");
      row.className = "saved-job-row" + (isSoon ? " deadline-soon" : "");
      row.innerHTML = `
        <div class="saved-job-info">
          <div>${escapeHtml(job.job_title || "Untitled")}${isSoon ? `<span class="deadline-soon-label">${daysLeft === 0 ? "Due today" : daysLeft + "d left"}</span>` : ""}</div>
          <div class="saved-job-company">${escapeHtml(job.company_name || "")}</div>
        </div>
        <div class="saved-job-actions">
          <label style="position:absolute;width:1px;height:1px;overflow:hidden;">Deadline for ${escapeHtml(job.job_title || "this job")}</label>
          <input type="date" class="sj-deadline-input" value="${job.deadline || ""}" />
          <button class="sj-save-btn">Save</button>
          <button class="sj-delete-btn">Remove</button>
        </div>
      `;

      row.querySelector(".sj-save-btn").addEventListener("click", () => updateSavedJobDeadline(job.id, row, token));
      row.querySelector(".sj-delete-btn").addEventListener("click", () => deleteSavedJob(job.id, token));

      savedJobsContentDiv.appendChild(row);
    });
  }

  async function updateSavedJobDeadline(id, row, token) {
    const deadline = row.querySelector(".sj-deadline-input").value || null;

    if (!window.confirm(deadline ? `Set the deadline to ${deadline}?` : "Clear this job's deadline?")) {
      return;
    }

    savedJobsStatus.textContent = "Saving...";
    savedJobsStatus.className = "";

    try {
      const response = await fetch(`http://localhost:3000/saved-jobs/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ deadline })
      });
      const data = await response.json();

      if (handleIfSessionExpired(response, data)) return;

      if (!response.ok) {
        // Point 7: the date input (row) isn't touched on failure — the
        // value the person picked is still sitting there to retry.
        savedJobsStatus.textContent = data.error || "Failed to update deadline.";
        savedJobsStatus.className = "error";
        return;
      }

      savedJobsStatus.textContent = "Deadline updated.";
      savedJobsStatus.className = "success";
      loadSavedJobs(token);
    } catch (err) {
      savedJobsStatus.innerHTML = "";
      const msg = document.createElement("span");
      msg.textContent = "Could not reach the server. ";
      const retryBtn = document.createElement("button");
      retryBtn.type = "button";
      retryBtn.className = "retry-btn";
      retryBtn.textContent = "Retry";
      retryBtn.style.marginLeft = "6px";
      retryBtn.addEventListener("click", () => updateSavedJobDeadline(id, row, token));
      savedJobsStatus.className = "error";
      savedJobsStatus.appendChild(msg);
      savedJobsStatus.appendChild(retryBtn);
    }
  }

  async function deleteSavedJob(id, token) {
    if (!window.confirm("Remove this saved job? This can't be undone.")) return;

    savedJobsStatus.textContent = "Removing...";
    savedJobsStatus.className = "";

    try {
      const response = await fetch(`http://localhost:3000/saved-jobs/${id}`, {
        method: "DELETE",
        headers: { "Authorization": `Bearer ${token}` }
      });
      const data = await response.json();

      if (handleIfSessionExpired(response, data)) return;

      if (!response.ok) {
        savedJobsStatus.textContent = data.error || "Failed to remove job.";
        savedJobsStatus.className = "error";
        return;
      }

      savedJobsStatus.textContent = "Removed.";
      savedJobsStatus.className = "success";
      loadSavedJobs(token);
    } catch (err) {
      savedJobsStatus.innerHTML = "";
      const msg = document.createElement("span");
      msg.textContent = "Could not reach the server. ";
      const retryBtn = document.createElement("button");
      retryBtn.type = "button";
      retryBtn.className = "retry-btn";
      retryBtn.textContent = "Retry";
      retryBtn.style.marginLeft = "6px";
      retryBtn.addEventListener("click", () => deleteSavedJob(id, token));
      savedJobsStatus.className = "error";
      savedJobsStatus.appendChild(msg);
      savedJobsStatus.appendChild(retryBtn);
    }
  }

  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }

  // ===== ACTIVITY (applied/saved counts — free plan only) =====

  async function loadActivity(token) {
    const activityCard = document.getElementById("activity-card");
    const appliedCountEl = document.getElementById("applied-count");
    const savedCountEl = document.getElementById("saved-count");
    const upgradeNote = document.getElementById("activity-upgrade-note");

    try {
      const response = await fetch("http://localhost:3000/activity", {
        headers: { "Authorization": `Bearer ${token}` }
      });
      const data = await response.json();

      if (response.status === 401) return;

      if (!response.ok) {
        if (currentPlan !== 'pro') {
          activityCard.style.display = "block";
          renderSectionError(document.getElementById("activity-detail-wrapper"), "Could not load activity counts.", () => loadActivity(token));
        }
        return;
      }

      if (data.plan === 'pro') {
        appliedKeys = new Set((data.applied || []).map(j => activityKey(j.job_title, j.company_name)));
        savedKeys = new Set((data.saved || []).map(j => activityKey(j.job_title, j.company_name)));
        activityCard.style.display = "none";

        if (fullHistory.length > 0) {
          const currentFilterEl = document.getElementById("history-filter");
          renderHistoryTable(currentFilterEl ? currentFilterEl.value : 'all');
        }
      } else {
        activityCard.style.display = "block";
        appliedCountEl.textContent = data.appliedCount;
        savedCountEl.textContent = data.savedCount;
        upgradeNote.style.display = "block";
      }
    } catch (err) {
      if (currentPlan !== 'pro') {
        activityCard.style.display = "block";
        renderSectionError(document.getElementById("activity-detail-wrapper"), "Could not reach the server to load activity.", () => loadActivity(token));
      }
    }
  }
});