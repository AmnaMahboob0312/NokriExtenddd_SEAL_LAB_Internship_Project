document.addEventListener("DOMContentLoaded", () => {
  const API_BASE = "http://localhost:3000";
  const statusDiv = document.getElementById("profile-status");
  const loadErrorBanner = document.getElementById("load-error-banner");
  const loadErrorText = document.getElementById("load-error-text");
  const loadRetryBtn = document.getElementById("load-retry-btn");
  const saveBtn = document.getElementById("save-profile-btn");

  function showLoadError(message) {
    loadErrorText.textContent = message;
    loadErrorBanner.classList.add("visible");
  }
  function clearLoadError() {
    loadErrorBanner.classList.remove("visible");
  }

  // Same session-expiry contract as dashboard.js/popup.js: a 401 with
  // sessionExpired:true means the token is stale, not that this request
  // was wrong. This page has no login form of its own (it's a full tab,
  // same as the dashboard), so the recovery here is directing the person
  // back to the popup rather than trying to log them in inline.
  async function authFetch(path, options = {}) {
    const stored = await new Promise((resolve) => chrome.storage.local.get(["nokriToken"], resolve));
    const token = stored.nokriToken;

    if (!token) {
      throw new Error("NOT_LOGGED_IN");
    }

    const response = await fetch(`${API_BASE}${path}`, {
      ...options,
      headers: { ...(options.headers || {}), "Authorization": `Bearer ${token}` }
    });

    if (response.status === 401) {
      const data = await response.clone().json().catch(() => ({}));
      chrome.storage.local.remove(["nokriToken", "nokriEmail", "nokriExpiresAt"]);
      throw new Error(data.sessionExpired ? "SESSION_EXPIRED" : "NOT_LOGGED_IN");
    }

    return response;
  }

  function handleAuthError(err) {
    document.querySelector(".nokri-card").style.display = "none";
    showLoadError(
      err.message === "SESSION_EXPIRED"
        ? "Your session has expired. Please log in again through the NokriExtenddd popup."
        : "Please log in through the NokriExtenddd popup to view your profile."
    );
    loadRetryBtn.style.display = "none"; // retrying won't help without logging in first
  }

  async function loadProfile() {
    clearLoadError();
    try {
      const response = await authFetch("/profile");
      if (!response.ok) {
        showLoadError("Could not load your profile. Please try again.");
        loadRetryBtn.style.display = "inline-block";
        return;
      }
      const data = await response.json();

      document.getElementById("profile-email").textContent = data.email || "";
      document.getElementById("full-name-input").value = data.full_name || "";
      document.getElementById("age-input").value = data.age ?? "";
      document.getElementById("gender-input").value = data.gender || "";
      document.getElementById("phone-input").value = data.phone || "";
      document.getElementById("city-input").value = data.city || "";
      document.getElementById("years-exp-input").value = data.years_experience ?? "";
      document.getElementById("employment-status-input").value = data.employment_status || "";
      document.getElementById("employment-type-input").value = data.employment_type || "";
    } catch (err) {
      if (err.message === "SESSION_EXPIRED" || err.message === "NOT_LOGGED_IN") {
        handleAuthError(err);
      } else {
        showLoadError("Could not reach the server. Is it running?");
        loadRetryBtn.style.display = "inline-block";
      }
    }
  }

  loadRetryBtn.addEventListener("click", loadProfile);
  loadProfile();

  // ===== INLINE VALIDATION (age / years of experience) =====

  function validateNumberField(inputId, errorId, min, max) {
    const input = document.getElementById(inputId);
    const errorDiv = document.getElementById(errorId);
    const raw = input.value.trim();

    if (raw === "") {
      input.classList.remove("field-invalid");
      errorDiv.textContent = "";
      return true;
    }

    const num = Number(raw);
    if (!Number.isFinite(num) || num < min || num > max) {
      input.classList.add("field-invalid");
      errorDiv.textContent = `Enter a number between ${min} and ${max}.`;
      return false;
    }

    input.classList.remove("field-invalid");
    errorDiv.textContent = "";
    return true;
  }

  document.getElementById("age-input").addEventListener("input", () => validateNumberField("age-input", "age-error", 13, 100));
  document.getElementById("years-exp-input").addEventListener("input", () => validateNumberField("years-exp-input", "years-exp-error", 0, 60));

  // ===== SAVE (with confirmation, per the "confirm before edits" requirement) =====

  async function attemptSaveProfile() {
    statusDiv.textContent = "";
    statusDiv.className = "";

    // Point 7: validation errors below leave every field exactly as typed —
    // nothing here clears the form, so the person just fixes the flagged
    // field and re-submits.
    const ageValid = validateNumberField("age-input", "age-error", 13, 100);
    const expValid = validateNumberField("years-exp-input", "years-exp-error", 0, 60);
    if (!ageValid || !expValid) {
      statusDiv.textContent = "Please fix the highlighted fields before saving.";
      statusDiv.className = "error";
      return;
    }

    const confirmed = window.confirm("Save changes to your profile?");
    if (!confirmed) return;

    const body = {
      full_name: document.getElementById("full-name-input").value.trim() || null,
      age: document.getElementById("age-input").value.trim() || null,
      gender: document.getElementById("gender-input").value || null,
      phone: document.getElementById("phone-input").value.trim() || null,
      city: document.getElementById("city-input").value.trim() || null,
      years_experience: document.getElementById("years-exp-input").value.trim() || null,
      employment_status: document.getElementById("employment-status-input").value || null,
      employment_type: document.getElementById("employment-type-input").value || null,
    };

    saveBtn.disabled = true;
    statusDiv.textContent = "Saving...";

    try {
      const response = await authFetch("/profile", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      const data = await response.json();

      if (!response.ok) {
        statusDiv.textContent = data.error || "Could not save your profile.";
        statusDiv.className = "error";
        return;
      }

      statusDiv.textContent = "Profile saved.";
      statusDiv.className = "success";
    } catch (err) {
      if (err.message === "SESSION_EXPIRED" || err.message === "NOT_LOGGED_IN") {
        handleAuthError(err);
      } else {
        // Point 8: recoverable, and point 7: the form still has everything
        // the person just typed — Retry re-submits the same body, no retyping.
        statusDiv.innerHTML = "";
        const msg = document.createElement("span");
        msg.textContent = "Could not reach the server. ";
        const retry = document.createElement("button");
        retry.type = "button";
        retry.className = "retry-btn";
        retry.textContent = "Retry";
        retry.style.marginLeft = "6px";
        retry.addEventListener("click", attemptSaveProfile);
        statusDiv.className = "error";
        statusDiv.appendChild(msg);
        statusDiv.appendChild(retry);
      }
    } finally {
      saveBtn.disabled = false;
    }
  }

  saveBtn.addEventListener("click", attemptSaveProfile);
});