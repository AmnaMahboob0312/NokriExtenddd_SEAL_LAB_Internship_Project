document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("contact-form");
  const nameInput = document.getElementById("contact-name");
  const emailInput = document.getElementById("contact-email");
  const messageInput = document.getElementById("contact-message");
  const submitBtn = document.getElementById("contact-submit-btn");
  const statusEl = document.getElementById("contact-status");

  const API_BASE = "http://localhost:3000";
  const DRAFT_KEY = "nokriContactDraft";

  // ===== PRESERVE ENTERED DATA (point 7) =====
  //
  // Two layers of protection: (1) on a failed submit, the fields are simply
  // never cleared — only a successful submit resets the form; (2) the draft
  // is also mirrored into chrome.storage.local as the person types, so even
  // an accidental tab close/reload during an error doesn't lose the message
  // they were writing.
  chrome.storage.local.get([DRAFT_KEY], (result) => {
    const draft = result[DRAFT_KEY];
    if (draft) {
      nameInput.value = draft.name || "";
      emailInput.value = draft.email || "";
      messageInput.value = draft.message || "";
    }
  });

  function saveDraft() {
    chrome.storage.local.set({
      [DRAFT_KEY]: {
        name: nameInput.value,
        email: emailInput.value,
        message: messageInput.value
      }
    });
  }

  [nameInput, emailInput, messageInput].forEach((el) => {
    el.addEventListener("input", saveDraft);
  });

  function clearDraft() {
    chrome.storage.local.remove([DRAFT_KEY]);
  }

  function renderError(message, { showRetry = true } = {}) {
    statusEl.innerHTML = "";
    statusEl.className = "error";
    const span = document.createElement("span");
    span.textContent = message;
    statusEl.appendChild(span);

    if (showRetry) {
      const retryBtn = document.createElement("button");
      retryBtn.type = "button";
      retryBtn.className = "retry-btn";
      retryBtn.textContent = "Retry";
      retryBtn.addEventListener("click", submitForm);
      statusEl.appendChild(retryBtn);
    }
  }

  function isValidEmailFormat(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }

  async function submitForm() {
    const name = nameInput.value.trim();
    const email = emailInput.value.trim();
    const message = messageInput.value.trim();

    statusEl.className = "";
    statusEl.textContent = "";

    if (!email || !isValidEmailFormat(email)) {
      renderError("Please enter a valid email address.", { showRetry: false });
      return;
    }
    if (!message) {
      renderError("Please enter a message.", { showRetry: false });
      return;
    }

    submitBtn.disabled = true;
    submitBtn.textContent = "Sending...";

    try {
      const response = await fetch(`${API_BASE}/contact`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: name || null, email, message })
      });
      const data = await response.json();

      submitBtn.disabled = false;
      submitBtn.textContent = "Send Message";

      if (!response.ok) {
        // Point 7: fields are left exactly as typed — nothing clears here.
        renderError(data.error || "Could not send your message. Please try again.");
        return;
      }

      // Only a genuine success clears the form and the saved draft.
      statusEl.className = "success";
      statusEl.textContent = "Message sent — thanks for reaching out!";
      form.reset();
      clearDraft();
    } catch (err) {
      submitBtn.disabled = false;
      submitBtn.textContent = "Send Message";
      // Point 7 + 8: fields stay populated, and Retry resubmits the same
      // (still-intact) values instead of asking the person to start over.
      renderError("Could not reach the server. Is it running?");
    }
  }

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    submitForm();
  });
});