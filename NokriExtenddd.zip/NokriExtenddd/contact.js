document.addEventListener("DOMContentLoaded", () => {
  const statusDiv = document.getElementById("contact-status");

  document.getElementById("contact-submit-btn").addEventListener("click", async () => {
    const name = document.getElementById("contact-name").value.trim();
    const email = document.getElementById("contact-email").value.trim();
    const message = document.getElementById("contact-message").value.trim();

    if (!email || !message) {
      statusDiv.textContent = "Email and message are required.";
      statusDiv.className = "error";
      return;
    }

    statusDiv.textContent = "Sending...";
    statusDiv.className = "";

    try {
      const response = await fetch("http://localhost:3000/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: name || null, email, message })
      });
      const data = await response.json();

      if (!response.ok) {
        statusDiv.textContent = data.error || "Failed to send message.";
        statusDiv.className = "error";
        return;
      }

      statusDiv.textContent = "Message sent — we'll get back to you soon.";
      statusDiv.className = "success";
      document.getElementById("contact-name").value = "";
      document.getElementById("contact-email").value = "";
      document.getElementById("contact-message").value = "";
    } catch (err) {
      statusDiv.textContent = "Could not reach the server. Is it running?";
      statusDiv.className = "error";
    }
  });
});