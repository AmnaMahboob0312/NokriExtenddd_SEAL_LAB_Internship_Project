document.addEventListener("DOMContentLoaded", () => {
  const loginView = document.getElementById("login-view");
  const preferencesView = document.getElementById("preferences-view");
  const resultsView = document.getElementById("results-view");
  const errorDiv = document.getElementById("error");
  const prefErrorDiv = document.getElementById("pref-error");
  const deadlineBanner = document.getElementById("deadline-banner");

  // Check if we already have a saved token
  chrome.storage.local.get(["nokriToken", "nokriEmail"], (result) => {
    if (result.nokriToken) {
      checkFirstUsePreferences(result.nokriEmail);
    }
  });

  document.getElementById("dashboard-btn").addEventListener("click", () => {
    chrome.tabs.create({ url: chrome.runtime.getURL("dashboard.html") });
  });

  document.getElementById("blacklist-btn").addEventListener("click", () => {
    chrome.tabs.create({ url: chrome.runtime.getURL("blacklist.html") });
  });

  document.getElementById("contact-btn").addEventListener("click", () => {
    chrome.tabs.create({ url: chrome.runtime.getURL("contact.html") });
  });

  document.getElementById("about-btn").addEventListener("click", () => {
    chrome.tabs.create({ url: chrome.runtime.getURL("about.html") });
  });

  document.getElementById("login-btn").addEventListener("click", async () => {
    const email = document.getElementById("email-input").value;
    const password = document.getElementById("password-input").value;
    errorDiv.textContent = "";

    try {
      const response = await fetch("http://localhost:3000/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password })
      });
      const result = await response.json();

      if (!response.ok) {
        errorDiv.textContent = result.error || "Login failed";
        return;
      }

      chrome.storage.local.set({ nokriToken: result.token, nokriEmail: result.user.email }, () => {
        checkFirstUsePreferences(result.user.email);
      });
    } catch (err) {
      errorDiv.textContent = "Could not reach server. Is it running?";
    }
  });

  document.getElementById("logout-btn").addEventListener("click", () => {
    chrome.storage.local.remove(["nokriToken", "nokriEmail"], () => {
      loginView.style.display = "block";
      preferencesView.style.display = "none";
      resultsView.style.display = "none";
    });
  });

  document.getElementById("save-preferences-btn").addEventListener("click", async () => {
    prefErrorDiv.textContent = "";

    const preferred_department = document.getElementById("pref-department").value.trim();
    const preferred_employment_type = document.getElementById("pref-employment-type").value.trim();
    const preferred_location = document.getElementById("pref-location").value.trim();
    const minSalaryRaw = document.getElementById("pref-min-salary").value.trim();
    const min_salary = minSalaryRaw ? parseFloat(minSalaryRaw) : null;

    chrome.storage.local.get(["nokriToken", "nokriEmail"], async (result) => {
      const token = result.nokriToken;
      if (!token) {
        prefErrorDiv.textContent = "You're not logged in anymore. Please log in again.";
        return;
      }

      try {
        const response = await fetch("http://localhost:3000/preferences", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${token}`
          },
          body: JSON.stringify({
            preferred_department: preferred_department || null,
            preferred_employment_type: preferred_employment_type || null,
            preferred_location: preferred_location || null,
            min_salary
          })
        });

        if (!response.ok) {
          const errResult = await response.json();
          prefErrorDiv.textContent = errResult.error || "Could not save preferences";
          return;
        }

        showResultsView(result.nokriEmail);
      } catch (err) {
        prefErrorDiv.textContent = "Could not reach server. Is it running?";
      }
    });
  });

  document.getElementById("skip-preferences-btn").addEventListener("click", () => {
    chrome.storage.local.get(["nokriEmail"], (result) => {
      showResultsView(result.nokriEmail);
    });
  });

  // Decides whether to show the preferences prompt or go straight to results.
  // Only shows the prompt if the user has never set ANY preference field.
  function checkFirstUsePreferences(email) {
    chrome.storage.local.get(["nokriToken"], async (result) => {
      const token = result.nokriToken;
      if (!token) {
        showResultsView(email);
        return;
      }

      try {
        const response = await fetch("http://localhost:3000/preferences", {
          headers: { "Authorization": `Bearer ${token}` }
        });
        const data = await response.json();
        const profiles = data.preferences || [];

        if (profiles.length === 0) {
          loginView.style.display = "none";
          resultsView.style.display = "none";
          preferencesView.style.display = "block";
        } else {
          showResultsView(email);
        }
      } catch (err) {
        // If the preferences check fails for any reason, don't block the user —
        // just fall through to results, same as before this feature existed.
        showResultsView(email);
      }
    });
  }

  function showResultsView(email) {
    loginView.style.display = "none";
    preferencesView.style.display = "none";
    resultsView.style.display = "block";
    document.getElementById("user-email").textContent = email;
    loadJobResults();
    checkUpcomingDeadlines();
    showIntroGuide();
  }

  // ===== "HOW TO USE" GUIDE (shown after every successful login) =====

  function showIntroGuide() {
    const introGuide = document.getElementById("intro-guide");
    const helpLink = document.getElementById("help-reopen-link");

    introGuide.innerHTML = `
      <strong>How NokriExtenddd works</strong>
      Open any LinkedIn job posting and a badge will appear on the page with a trust score for that listing.
      <ul>
        <li><strong>Save / Applied</strong> on the badge — logs your activity, visible in your dashboard</li>
        <li><strong>View Dashboard</strong> — your screening history, stats, preferences, and saved jobs</li>
        <li><strong>Reported Companies</strong> — a reviewed list of companies flagged by other users</li>
        <li><strong>Contact Us</strong> — send us a question or report an issue</li>
        <li><strong>About Us</strong> — who built NokriExtenddd, and our privacy policy</li>
      </ul>
      <button id="intro-dismiss-btn">Got it</button>
    `;
    introGuide.style.display = "block";
    helpLink.style.display = "none";

    document.getElementById("intro-dismiss-btn").addEventListener("click", () => {
      introGuide.style.display = "none";
      helpLink.style.display = "block";
    });
  }

  document.getElementById("help-reopen-link").addEventListener("click", () => {
    showIntroGuide();
  });

  function loadJobResults() {
    const resultsDiv = document.getElementById("results");

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const currentTab = tabs[0];

      if (!currentTab.url || !currentTab.url.includes("linkedin.com")) {
        resultsDiv.textContent = "Open a LinkedIn job posting to see results.";
        return;
      }

      chrome.tabs.sendMessage(currentTab.id, { type: "GET_SCRAPED_DATA" }, (response) => {
        if (chrome.runtime.lastError || !response) {
          resultsDiv.textContent = "No job data found yet. Try refreshing the LinkedIn page.";
          return;
        }

        resultsDiv.innerHTML = `
          <p><strong>Title:</strong> ${response.job_title || "—"}</p>
          <p><strong>Company:</strong> ${response.company_name || "—"}</p>
          <p><strong>Location:</strong> ${response.location || "—"}</p>
          <p><strong>Type:</strong> ${response.employment_type || "—"}</p>
        `;
      });
    });
  }

  // ===== DEADLINE REMINDER BANNER (Pro plan only) =====

  function daysUntil(dateStr) {
    // deadline is a plain 'YYYY-MM-DD' string — parse as local midnight to
    // avoid the timezone shift that plain Date parsing of ISO strings causes
    const target = new Date(dateStr + "T00:00:00");
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return Math.round((target.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
  }

  function checkUpcomingDeadlines() {
    chrome.storage.local.get(["nokriToken"], async (result) => {
      const token = result.nokriToken;
      if (!token) return;

      try {
        const dashboardResponse = await fetch("http://localhost:3000/dashboard", {
          headers: { "Authorization": `Bearer ${token}` }
        });
        const dashboardData = await dashboardResponse.json();

        // Deadline reminders are a Pro-only feature — free users never see this banner
        if (!dashboardResponse.ok || dashboardData.plan !== "pro") {
          deadlineBanner.style.display = "none";
          return;
        }

        const jobsResponse = await fetch("http://localhost:3000/saved-jobs", {
          headers: { "Authorization": `Bearer ${token}` }
        });
        const jobsData = await jobsResponse.json();

        if (!jobsResponse.ok) {
          deadlineBanner.style.display = "none";
          return;
        }

        const jobsDueSoon = (jobsData.savedJobs || [])
          .filter(job => job.deadline)
          .map(job => ({ ...job, daysLeft: daysUntil(job.deadline) }))
          .filter(job => job.daysLeft >= 0 && job.daysLeft <= 2)
          .sort((a, b) => a.daysLeft - b.daysLeft);

        if (jobsDueSoon.length === 0) {
          deadlineBanner.style.display = "none";
          return;
        }

        const soonest = jobsDueSoon[0];
        const dueText = soonest.daysLeft === 0 ? "due today" : `due in ${soonest.daysLeft} day${soonest.daysLeft === 1 ? "" : "s"}`;
        const extraCount = jobsDueSoon.length - 1;

        deadlineBanner.innerHTML = `
          <strong>Deadline coming up</strong>
          "${soonest.job_title}" at ${soonest.company_name} is ${dueText}.
          ${extraCount > 0 ? `<br>+${extraCount} more job${extraCount === 1 ? "" : "s"} due soon.` : ""}
        `;
        deadlineBanner.style.display = "block";
      } catch (err) {
        deadlineBanner.style.display = "none";
      }
    });
  }
});