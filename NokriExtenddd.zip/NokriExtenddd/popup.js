document.addEventListener("DOMContentLoaded", () => {
  const loginView = document.getElementById("login-view");
  const signupView = document.getElementById("signup-view");
  const preferencesView = document.getElementById("preferences-view");
  const resultsView = document.getElementById("results-view");
  const errorDiv = document.getElementById("error");
  const signupErrorDiv = document.getElementById("signup-error");
  const signupSuccessDiv = document.getElementById("signup-success");
  const prefErrorDiv = document.getElementById("pref-error");
  const deadlineBanner = document.getElementById("deadline-banner");
  const sessionNotice = document.getElementById("session-notice");
  const globalErrorBanner = document.getElementById("global-error-banner");
  const globalErrorText = document.getElementById("global-error-text");
  const globalErrorRetryBtn = document.getElementById("global-error-retry-btn");

  const API_BASE = "http://localhost:3000";

  // ===== ERROR STATES WITH RECOVERY (point 8) =====
  function showRecoverableError(message, retryFn) {
    globalErrorText.textContent = message;
    globalErrorBanner.classList.add("visible");
    globalErrorRetryBtn.onclick = () => {
      globalErrorBanner.classList.remove("visible");
      retryFn();
    };
  }

  function clearRecoverableError() {
    globalErrorBanner.classList.remove("visible");
    globalErrorRetryBtn.onclick = null;
  }

  // ===== SESSION HELPERS =====

  function showSessionNotice(message) {
    sessionNotice.textContent = message;
    sessionNotice.style.display = "block";
  }

  function clearSessionNotice() {
    sessionNotice.style.display = "none";
    sessionNotice.textContent = "";
  }

  function goToLoginView(message) {
    loginView.style.display = "block";
    signupView.style.display = "none";
    preferencesView.style.display = "none";
    resultsView.style.display = "none";
    if (message) showSessionNotice(message);
  }

  function isSessionExpired(expiresAt) {
    return !expiresAt || Date.now() >= expiresAt;
  }

  function logoutLocally() {
    chrome.storage.local.remove(["nokriToken", "nokriEmail", "nokriExpiresAt"]);
  }

  async function authFetch(path, options = {}) {
    const stored = await new Promise((resolve) => {
      chrome.storage.local.get(["nokriToken"], resolve);
    });
    const token = stored.nokriToken;

    if (!token) {
      goToLoginView("You're not logged in anymore. Please log in again.");
      throw new Error("No token");
    }

    const response = await fetch(`${API_BASE}${path}`, {
      ...options,
      headers: {
        ...(options.headers || {}),
        "Authorization": `Bearer ${token}`
      }
    });

    if (response.status === 401) {
      let payload = {};
      try { payload = await response.clone().json(); } catch (e) { /* ignore */ }
      logoutLocally();
      goToLoginView(payload.error || "Your session has expired. Please log in again.");
      throw new Error("Session expired");
    }

    return response;
  }

  chrome.storage.local.get(["nokriToken", "nokriEmail", "nokriExpiresAt"], (result) => {
    if (result.nokriToken && !isSessionExpired(result.nokriExpiresAt)) {
      checkFirstUsePreferences(result.nokriEmail);
    } else if (result.nokriToken) {
      logoutLocally();
      showSessionNotice("Your session expired. Please log in again.");
    }
  });

  document.getElementById("dashboard-btn").addEventListener("click", () => {
    chrome.tabs.create({ url: chrome.runtime.getURL("dashboard.html") });
  });

  document.getElementById("blacklist-btn").addEventListener("click", () => {
    chrome.tabs.create({ url: chrome.runtime.getURL("blacklist.html") });
  });

  document.getElementById("contact-btn").addEventListener("click", () => {
    chrome.tabs.create({ url: chrome.runtime.getURL("contact.html") });
  });

  document.getElementById("about-btn").addEventListener("click", () => {
    chrome.tabs.create({ url: chrome.runtime.getURL("about.html") });
  });

  document.getElementById("view-profile-btn").addEventListener("click", () => {
    chrome.tabs.create({ url: chrome.runtime.getURL("profile.html") });
  });

  // ===== LOGIN =====
  //
  // Point 7 (preserve entered data on error): neither field is cleared on
  // a failed login — only errorDiv gets a message, so the person can just
  // fix the typo and resubmit instead of retyping both fields.

  function attemptLogin() {
    const email = document.getElementById("email-input").value;
    const password = document.getElementById("password-input").value;
    errorDiv.textContent = "";
    clearSessionNotice();

    fetch(`${API_BASE}/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password })
    })
      .then(async (response) => {
        const result = await response.json();
        if (!response.ok) {
          errorDiv.textContent = result.error || "Login failed";
          return;
        }
        chrome.storage.local.set(
          { nokriToken: result.token, nokriEmail: result.user.email, nokriExpiresAt: result.expiresAt },
          () => {
            checkFirstUsePreferences(result.user.email);
          }
        );
      })
      .catch(() => {
        // Network/server-down failure is distinct from a bad password —
        // give a Retry action right in the inline error rather than only
        // a static message, since re-clicking Log In with the same
        // (still-intact) fields is exactly the right recovery here.
        errorDiv.innerHTML = "";
        const msg = document.createElement("span");
        msg.textContent = "Could not reach server. Is it running? ";
        const retry = document.createElement("button");
        retry.type = "button";
        retry.className = "retry-btn";
        retry.textContent = "Retry";
        retry.style.marginLeft = "6px";
        retry.addEventListener("click", attemptLogin);
        errorDiv.appendChild(msg);
        errorDiv.appendChild(retry);
      });
  }

  document.getElementById("login-btn").addEventListener("click", attemptLogin);

  document.getElementById("logout-btn").addEventListener("click", () => {
    logoutLocally();
    goToLoginView();
  });

  // ===== SIGN UP: SWITCHING BETWEEN LOGIN / SIGN UP =====

  document.getElementById("show-signup-link").addEventListener("click", (e) => {
    e.preventDefault();
    errorDiv.textContent = "";
    clearSessionNotice();
    loginView.style.display = "none";
    signupView.style.display = "block";
  });

  document.getElementById("show-login-link").addEventListener("click", (e) => {
    e.preventDefault();
    signupErrorDiv.textContent = "";
    signupSuccessDiv.textContent = "";
    signupView.style.display = "none";
    loginView.style.display = "block";
  });

  // ===== SIGN UP: PASSWORD VISIBILITY TOGGLES =====

  function wireVisibilityToggle(buttonId, inputId) {
    const btn = document.getElementById(buttonId);
    const input = document.getElementById(inputId);
    btn.addEventListener("click", () => {
      const isHidden = input.type === "password";
      input.type = isHidden ? "text" : "password";
      btn.textContent = isHidden ? "🙈" : "👁";
      btn.title = isHidden ? "Hide password" : "Show password";
      btn.setAttribute("aria-label", btn.title);
    });
  }

  wireVisibilityToggle("password-toggle-btn", "password-input");
  wireVisibilityToggle("signup-password-toggle-btn", "signup-password-input");
  wireVisibilityToggle("signup-confirm-toggle-btn", "signup-confirm-input");

  // ===== SIGN UP: INLINE VALIDATION =====

  const signupEmailInput = document.getElementById("signup-email-input");
  const signupPasswordInput = document.getElementById("signup-password-input");
  const signupConfirmInput = document.getElementById("signup-confirm-input");
  const signupEmailHint = document.getElementById("signup-email-hint");
  const signupConfirmHint = document.getElementById("signup-confirm-hint");
  const signupBtn = document.getElementById("signup-btn");
  const ruleEls = {
    length: document.querySelector('[data-rule="length"]'),
    lower: document.querySelector('[data-rule="lower"]'),
    upper: document.querySelector('[data-rule="upper"]'),
    number: document.querySelector('[data-rule="number"]'),
    special: document.querySelector('[data-rule="special"]')
  };

  function isValidEmailFormat(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }

  function getPasswordRuleStatus(password) {
    return {
      length: password.length >= 8,
      lower: /[a-z]/.test(password),
      upper: /[A-Z]/.test(password),
      number: /[0-9]/.test(password),
      special: /[^A-Za-z0-9]/.test(password)
    };
  }

  function updateSignupValidation() {
    const email = signupEmailInput.value.trim();
    const password = signupPasswordInput.value;
    const confirm = signupConfirmInput.value;

    if (email.length === 0) {
      signupEmailHint.textContent = "";
      signupEmailHint.className = "";
      signupEmailInput.classList.remove("field-valid", "field-invalid");
    } else if (isValidEmailFormat(email)) {
      signupEmailHint.textContent = "";
      signupEmailHint.className = "";
      signupEmailInput.classList.add("field-valid");
      signupEmailInput.classList.remove("field-invalid");
    } else {
      signupEmailHint.textContent = "That doesn't look like a valid email address.";
      signupEmailHint.className = "bad";
      signupEmailInput.classList.add("field-invalid");
      signupEmailInput.classList.remove("field-valid");
    }

    const status = getPasswordRuleStatus(password);
    let allRulesMet = true;
    Object.keys(ruleEls).forEach((rule) => {
      const met = status[rule];
      if (!met) allRulesMet = false;
      const el = ruleEls[rule];
      el.classList.toggle("met", met);
      el.classList.toggle("unmet", !met);
      el.querySelector(".rule-icon").textContent = met ? "✓" : "○";
    });

    let confirmOk = false;
    if (confirm.length === 0) {
      signupConfirmHint.textContent = "";
      signupConfirmHint.className = "";
      signupConfirmInput.classList.remove("field-valid", "field-invalid");
    } else if (confirm === password) {
      signupConfirmHint.textContent = "Passwords match.";
      signupConfirmHint.className = "ok";
      signupConfirmInput.classList.add("field-valid");
      signupConfirmInput.classList.remove("field-invalid");
      confirmOk = true;
    } else {
      signupConfirmHint.textContent = "Passwords don't match yet.";
      signupConfirmHint.className = "bad";
      signupConfirmInput.classList.add("field-invalid");
      signupConfirmInput.classList.remove("field-valid");
    }

    const emailOk = isValidEmailFormat(email);
    signupBtn.disabled = !(emailOk && allRulesMet && confirmOk);
  }

  signupEmailInput.addEventListener("input", updateSignupValidation);
  signupPasswordInput.addEventListener("input", updateSignupValidation);
  signupConfirmInput.addEventListener("input", updateSignupValidation);

  // ===== SIGN UP: SUBMIT =====

  function attemptSignup() {
    signupErrorDiv.textContent = "";
    signupSuccessDiv.textContent = "";

    const email = signupEmailInput.value.trim();
    const password = signupPasswordInput.value;

    fetch(`${API_BASE}/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password })
    })
      .then(async (response) => {
        const result = await response.json();
        if (!response.ok) {
          signupErrorDiv.textContent = result.error || "Could not create your account.";
          return;
        }

        signupSuccessDiv.textContent = "Account created! Please log in below.";
        signupPasswordInput.value = "";
        signupConfirmInput.value = "";

        setTimeout(() => {
          signupView.style.display = "none";
          loginView.style.display = "block";
          document.getElementById("email-input").value = email;
          document.getElementById("password-input").focus();
          signupSuccessDiv.textContent = "";
        }, 1200);
      })
      .catch(() => {
        signupErrorDiv.innerHTML = "";
        const msg = document.createElement("span");
        msg.textContent = "Could not reach server. Is it running? ";
        const retry = document.createElement("button");
        retry.type = "button";
        retry.className = "retry-btn";
        retry.textContent = "Retry";
        retry.style.marginLeft = "6px";
        retry.addEventListener("click", attemptSignup);
        signupErrorDiv.appendChild(msg);
        signupErrorDiv.appendChild(retry);
      });
  }

  signupBtn.addEventListener("click", attemptSignup);

  // ===== PREFERENCES (onboarding, first login only) =====

  function attemptSavePreferences() {
    prefErrorDiv.textContent = "";

    const preferred_department = document.getElementById("pref-department").value.trim();
    const preferred_employment_type = document.getElementById("pref-employment-type").value.trim();
    const preferred_location = document.getElementById("pref-location").value.trim();
    const minSalaryRaw = document.getElementById("pref-min-salary").value.trim();
    const min_salary = minSalaryRaw ? parseFloat(minSalaryRaw) : null;

    const confirmed = window.confirm("Save these job preferences to your account?");
    if (!confirmed) return;

    chrome.storage.local.get(["nokriEmail"], async (stored) => {
      try {
        const response = await authFetch("/preferences", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            preferred_department: preferred_department || null,
            preferred_employment_type: preferred_employment_type || null,
            preferred_location: preferred_location || null,
            min_salary
          })
        });

        if (!response.ok) {
          const errResult = await response.json();
          prefErrorDiv.textContent = errResult.error || "Could not save preferences";
          return;
        }

        showResultsView(stored.nokriEmail);
      } catch (err) {
        if (err.message !== "Session expired" && err.message !== "No token") {
          prefErrorDiv.innerHTML = "";
          const msg = document.createElement("span");
          msg.textContent = "Could not reach server. Is it running? ";
          const retry = document.createElement("button");
          retry.type = "button";
          retry.className = "retry-btn";
          retry.textContent = "Retry";
          retry.style.marginLeft = "6px";
          retry.addEventListener("click", attemptSavePreferences);
          prefErrorDiv.appendChild(msg);
          prefErrorDiv.appendChild(retry);
        }
      }
    });
  }

  document.getElementById("save-preferences-btn").addEventListener("click", attemptSavePreferences);

  document.getElementById("skip-preferences-btn").addEventListener("click", () => {
    chrome.storage.local.get(["nokriEmail"], (result) => {
      showResultsView(result.nokriEmail);
    });
  });

  function checkFirstUsePreferences(email) {
    chrome.storage.local.get(["nokriToken"], async (result) => {
      const token = result.nokriToken;
      if (!token) {
        showResultsView(email);
        return;
      }

      try {
        const response = await authFetch("/preferences");
        const data = await response.json();
        const profiles = data.preferences || [];

        if (profiles.length === 0) {
          loginView.style.display = "none";
          signupView.style.display = "none";
          resultsView.style.display = "none";
          preferencesView.style.display = "block";
        } else {
          showResultsView(email);
        }
      } catch (err) {
        if (err.message !== "Session expired" && err.message !== "No token") {
          showResultsView(email);
        }
      }
    });
  }

  function showResultsView(email) {
    clearSessionNotice();
    clearRecoverableError();
    loginView.style.display = "none";
    signupView.style.display = "none";
    preferencesView.style.display = "none";
    resultsView.style.display = "block";
    document.getElementById("user-email").textContent = email;
    checkUpcomingDeadlines();

    // Show the guide automatically unless the person already dismissed it
    // on a previous login — after that it's only reachable via the
    // "How to use NokriExtenddd" link, not shown unprompted every time.
    chrome.storage.local.get(["nokriIntroDismissed"], (result) => {
      if (!result.nokriIntroDismissed) {
        showIntroGuide();
      } else {
        document.getElementById("help-reopen-link").style.display = "block";
      }
    });
  }

  // ===== "HOW TO USE" GUIDE =====

  function showIntroGuide() {
    const introGuide = document.getElementById("intro-guide");
    const helpLink = document.getElementById("help-reopen-link");

    // Dismiss button placed right under the heading — not after the bullet
    // list — so it's reachable without scrolling the popup.
    introGuide.innerHTML = `
      <strong>How NokriExtenddd works</strong>
      <button id="intro-dismiss-btn">Got it</button>
      <div style="margin-top: 0.5rem;">
        Open any LinkedIn job posting and a badge will appear on the page with a trust score for that listing.
        <ul>
          <li><strong>Save / Applied</strong> on the badge — logs your activity, visible in your dashboard</li>
          <li><strong>View My Profile</strong> — your personal details as a job seeker</li>
          <li><strong>View Dashboard</strong> — your screening history, stats, preferences, and saved jobs</li>
          <li><strong>Reported Companies</strong> — a reviewed list of companies flagged by other users</li>
          <li><strong>Contact Us</strong> — send us a question or report an issue</li>
          <li><strong>About Us</strong> — who built NokriExtenddd, and our privacy policy</li>
        </ul>
      </div>
    `;
    introGuide.style.display = "block";
    helpLink.style.display = "none";

    document.getElementById("intro-dismiss-btn").addEventListener("click", () => {
      introGuide.style.display = "none";
      helpLink.style.display = "block";
      // Persisted — per the updated requirement, once dismissed it stays
      // collapsed on future logins too, not just for this popup session.
      // The "How to use NokriExtenddd" link below still reopens it anytime.
      chrome.storage.local.set({ nokriIntroDismissed: true });
    });
  }

  document.getElementById("help-reopen-link").addEventListener("click", () => {
    showIntroGuide();
  });

  // ===== DEADLINE REMINDER BANNER (Pro plan only) =====

  function daysUntil(dateStr) {
    const target = new Date(dateStr + "T00:00:00");
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return Math.round((target.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
  }

  function checkUpcomingDeadlines() {
    chrome.storage.local.get(["nokriToken"], async (result) => {
      const token = result.nokriToken;
      if (!token) return;

      try {
        const dashboardResponse = await authFetch("/dashboard");
        const dashboardData = await dashboardResponse.json();

        if (!dashboardResponse.ok || dashboardData.plan !== "pro") {
          deadlineBanner.style.display = "none";
          return;
        }

        const jobsResponse = await authFetch("/saved-jobs");
        const jobsData = await jobsResponse.json();

        if (!jobsResponse.ok) {
          deadlineBanner.style.display = "none";
          return;
        }

        const jobsDueSoon = (jobsData.savedJobs || [])
          .filter(job => job.deadline)
          .map(job => ({ ...job, daysLeft: daysUntil(job.deadline) }))
          .filter(job => job.daysLeft >= 0 && job.daysLeft <= 2)
          .sort((a, b) => a.daysLeft - b.daysLeft);

        if (jobsDueSoon.length === 0) {
          deadlineBanner.style.display = "none";
          return;
        }

        const soonest = jobsDueSoon[0];
        const dueText = soonest.daysLeft === 0 ? "due today" : `due in ${soonest.daysLeft} day${soonest.daysLeft === 1 ? "" : "s"}`;
        const extraCount = jobsDueSoon.length - 1;

        deadlineBanner.innerHTML = `
          <strong>Deadline coming up</strong>
          "${soonest.job_title}" at ${soonest.company_name} is ${dueText}.
          ${extraCount > 0 ? `<br>+${extraCount} more job${extraCount === 1 ? "" : "s"} due soon.` : ""}
        `;
        deadlineBanner.style.display = "block";
      } catch (err) {
        if (err.message !== "Session expired" && err.message !== "No token") {
          showRecoverableError(
            "Couldn't check for upcoming deadlines. Is the server running?",
            checkUpcomingDeadlines
          );
        } else {
          deadlineBanner.style.display = "none";
        }
      }
    });
  }
});