# Fake Job Detector — Full Architecture & Spec (v2)

> Status: prototype-stage. ML model is a 202-row / 10-column logistic regression trained in Colab. Treat "Job Score" as beta-quality until retrained on more data — flagged throughout as **[VALIDATE]**.

## Tool Stack (as specified)
| Tool | Role |
|---|---|
| Chrome Extension APIs | Client — runs in-browser, scrapes LinkedIn, shows results |
| Node.js | Backend API server |
| node-cron | Scheduled jobs inside the Node backend (deadline reminder checks) |
| PostgreSQL | Primary database — users, screenings, blacklist, subscriptions |
| Python + scikit-learn | Model training (logistic regression) |
| Google Colab | Where the model is currently trained/experimented on |
| VS Code | Your code editor for building extension + backend |

**[VALIDATE — decision made for you]** Node.js cannot run a scikit-learn `.pkl` model natively. Since you didn't list a Python web framework (Flask/FastAPI) in your tools, you have two real choices — pick one deliberately, don't let it happen by default:
- **(a)** Add a lightweight Python service (Flask) just to serve predictions — cleanest, but adds a tool you didn't list.
- **(b)** Export the trained model to ONNX format and load it in Node via `onnxruntime-node` — keeps you to pure Node.js/Postgres, but adds a conversion step.
For a same-day build, **(a)** is faster to get working since you already have Python/sklearn code from Colab. I'll assume (a) below; swap if you choose (b).

---

## 1. Architecture — Components & Data Flow

| Component | Job | Runs where |
|---|---|---|
| Content script | Scrapes job fields from LinkedIn DOM: `job_title, company_name, company_description, job_description, job_requirement, salary, location, employment_type, department` | Injected on linkedin.com |
| Badge injector | Renders the score/verdict visually on the page | Injected on linkedin.com |
| Background service worker | Auth token, message routing, API calls | Extension background |
| Popup UI | Current job's score + quota | Extension icon click |
| Options/Dashboard page | Stats, history, preferences, billing, blacklist-site link | Extension full-page tab |
| Node.js API | Auth, scoring orchestration, preferences, quota, billing, blacklist, dashboard stats | Your server |
| node-cron job (inside Node API) | Daily scan of `saved_jobs` for deadlines tomorrow → triggers notification | Same server, scheduled |
| Python/Flask model service | `POST /predict` → takes the 9 input fields → returns fraud probability | Separate small service |
| PostgreSQL | All persistent data | Managed DB instance |
| Public blacklist website | Static/simple site reading from the same blacklist table (read-only) | Separate small deployment |

### Data flow

```
[Content Script] --9 scraped fields--> [Background Worker]
[Background Worker] --fields + auth token--> [Node API /score]
[Node API] --9 fields--> [Flask Model Service] --fraud_probability--> [Node API]
[Node API] --company_name/job hash--> [Postgres: blacklist table] --match?--> [Node API]
[Node API] --preferences check--> [Postgres: preferences table]
[Node API] --aggregate score, log--> [Postgres: screenings table]
[Node API] --score + verdict + quota_remaining--> [Background Worker] --> [Content Script renders badge]
[node-cron] --daily--> [Postgres: saved_jobs] --deadline tomorrow?--> [Notification to user]
[Public website] --read-only query--> [Postgres: blacklist table]
```

**Rule:** every arrow above is the only allowed path. Content script/popup never queries Postgres or the model service directly — always through the Node API. This is what makes Section 6 (security) actually enforceable rather than just a suggestion.

---

## 2. Requirement-by-requirement build spec

### 1) Job Score
- **Inputs:** the 9 non-target columns your model uses: `job_title, company_name, company_description, job_description, job_requirement, salary, location, employment_type, department`
- **Formula (draft — [VALIDATE], this is a product judgment call, not just code):**
  `final_score = (w1 × ml_probability) + (w2 × blacklist_flag) + (w3 × rule_checks)`
  where `rule_checks` covers cheap heuristics your 202-row model can't reliably learn yet (e.g. salary wildly outside market range for the role/location, generic free-email domains in company_description, missing requirements section). Start with `w1=0.6, w2=0.3, w3=0.1` and tune once you have real user feedback — don't treat these numbers as final.
- Output: 0–100, higher = more likely fake.

### 2) Custom validation checks
- Stored per-user in `preferences` table (e.g. `seniority_level`, `role_category` as text/enum fields)
- Checked independently of the fraud score — a real, non-fake job can still be "flagged" here as "doesn't match your criteria," which is a **different flag type** in the UI from "likely fraudulent." Don't merge these into one score — a senior user should see they're different reasons.

### 3) 200/month quota
- `screenings` table logs every check with `user_id` + `timestamp`
- Node API counts rows for current billing month before running a new screening; blocks + returns upgrade prompt if ≥200
- **[VALIDATE]** Must be enforced server-side only (see Security section) — never trust a count sent from the extension.

### 4) ML model + "self-improving" behavior tracking
- Model service takes the 9 fields, returns probability, per the Colab-trained logistic regression
- **Behavior tracking (apply/save/flag actions)** should be logged now (it's cheap — just Postgres rows) but **retraining the model on this data is a separate, later project**, not something to build into today's deadline. Log the data; don't build an auto-retraining pipeline yet — that needs its own validation step (imbalanced classes, feedback loops where user bias reinforces model bias, etc.)

### 5) Chrome extension for LinkedIn
- Manifest V3, `host_permissions` scoped to `*://*.linkedin.com/*` only (not broader)

### 6) Real-time + deadline notifications
- Real-time: triggered synchronously right after the `/score` API call returns
- Deadline (pro only): `node-cron` job, runs once daily, queries `saved_jobs WHERE deadline = tomorrow AND user.plan = 'pro'`

### 7) Centralized blacklist
- `blacklist` table: company_name (or normalized hash), reason, flagged_count, approved_by (if you want human review before something is added — recommended, since a wrongly blacklisted real company is a legal/reputation risk for you)
- Checked on every screening, contributes to the score (see formula above)

### 8) User dashboard, tiered detail
- Free: aggregate counts only (`SELECT COUNT(*) ... GROUP BY status`)
- Pro: full per-job list (`SELECT * FROM screenings WHERE user_id = ...`)
- **[VALIDATE — security-critical]** this tier check must happen in the Node API query logic itself, not just hidden in the frontend — a free user calling the API directly must not be able to retrieve the detailed rows.

### 9) Model inputs — noted above, drives both the model service's expected request shape and the content script's required scrape fields. These must match exactly, field-for-field, or the model service will error or silently mispredict.

### 10) Public blacklist website
- Simplest version: a static page (or small separate Node app) doing a read-only query against the `blacklist` table
- **[VALIDATE]** Decide now: does this site require login, or is it fully public? Public means anyone (including the companies you've blacklisted) can see it — real defamation/legal exposure if a listing is wrong. Recommend: require the "approved_by" review step in #7 before anything appears here.

---

## 3. Functional Requirements
1. System shall scrape the 9 defined job fields from a LinkedIn job posting page.
2. System shall submit scraped fields to the model service and receive a fraud probability.
3. System shall combine ML probability, blacklist match, and rule-based checks into a single 0–100 Job Score per the formula above.
4. System shall check custom user preferences and flag non-matching posts, distinct from the fraud flag.
5. System shall track and enforce a 200-screening/month limit for free-tier users, server-side.
6. System shall render a visible on-page badge for every screened post.
7. System shall send real-time flag notifications and (pro-only) deadline reminder notifications for saved jobs.
8. System shall maintain and query a centralized blacklist against every screening.
9. System shall provide a tiered dashboard (aggregate stats free / full detail pro).
10. System shall log user actions (apply/save/flag) for future retraining, without auto-retraining in v1.
11. System shall expose a public, read-only blacklist website.

## 4. Non-Functional Requirements
| Category | Requirement |
|---|---|
| Performance | End-to-end scrape→score→badge under ~2s |
| Availability | Graceful failure if model service is down (show "unavailable," don't crash) |
| Privacy | Job post text + user behavior leaves the device — disclose in privacy policy (required for Chrome Web Store) |
| Security | Server-side enforcement of all tier/quota checks (see below) |
| Legal | **[VALIDATE — not resolved for you]** LinkedIn ToS re: scraping; blacklist site defamation risk |
| Maintainability | Model service interface (9 fields in → probability out) stays stable even as the model itself is retrained/improved |
| Data quality | 202-row model — accuracy claims to users should be framed as beta/experimental, not authoritative |

## 5. Deployment & Access
- **Extension:** Chrome Web Store (once ready) — for today's deadline, "Load unpacked" in `chrome://extensions` for local testing is enough
- **Node API + Postgres + node-cron:** any Node-friendly host (Render/Railway/etc.) with a managed Postgres add-on
- **Flask model service:** small separate deployment (can be same host, different service/port)
- **Blacklist website:** separate static/small deployment, read-only DB access only (its own restricted DB credentials — never give it write access)
- **Access by plan:**
  - Free: 200 screenings/month, aggregate dashboard stats only, real-time flag notifications
  - Pro: unlimited screenings, full per-job dashboard detail, deadline reminders

## 6. Security & Access Control
- Never trust the client — all plan/quota checks re-verified server-side on every request using the authenticated user's actual DB record
- JWT auth on every API call except the public blacklist read endpoint
- Row-level scoping: every user-data query filtered by `user_id` from the verified token, never from client-supplied input
- `manifest.json` permissions scoped to `linkedin.com` only
- No API keys/secrets shipped inside extension code
- HTTPS between all services
- Blacklist writes require the review/approval step (#7) — no direct user-triggered writes to a public-facing table

## 7. UI Constraints
- Manifest V3: service worker (not persistent background page), strict CSP, no inline scripts
- Popup: score + quota glance only; full detail lives in the dashboard tab
- Badge injection must not break LinkedIn's existing layout — verify against the live DOM, it changes periodically

## 8. Generation Boundaries
**Generate freely:** manifest.json, Express/Node routes, Postgres schema, dashboard/popup UI, node-cron job scaffolding, Flask service scaffolding.
**Generate then validate yourself:** the score formula weights, DOM scraper selectors (brittle, must test live), quota/tier enforcement logic (try to break it as a free user).
**Don't treat as done without outside input:** the ML model's real-world accuracy (202 rows is a genuine limitation), the blacklist site's legal exposure, LinkedIn ToS compliance.
