document.addEventListener("DOMContentLoaded", () => {
  const contentDiv = document.getElementById("blacklist-content");

  chrome.storage.local.get(["nokriToken"], async (result) => {
    const token = result.nokriToken;

    if (!token) {
      contentDiv.innerHTML = `<p>Please log in through the extension popup first.</p>`;
      return;
    }

    try {
      const response = await fetch("http://localhost:3000/blacklist", {
        headers: { "Authorization": `Bearer ${token}` }
      });
      const data = await response.json();

      if (!response.ok) {
        contentDiv.innerHTML = `<p>Error: ${data.error || "Could not load the blacklist."}</p>`;
        return;
      }

      renderBlacklist(data.blacklist || []);
    } catch (err) {
      contentDiv.innerHTML = `<p>Could not reach the server. Is it running?</p>`;
    }
  });

  function renderBlacklist(entries) {
    if (entries.length === 0) {
      contentDiv.innerHTML = `<p>No reviewed reports yet.</p>`;
      return;
    }

    const rows = entries.map(entry => `
      <tr>
        <td>${escapeHtml(entry.company_name)}</td>
        <td>${escapeHtml(entry.reason || "—")}</td>
        <td><span class="flag-count">${entry.flagged_count} report${entry.flagged_count === 1 ? "" : "s"}</span></td>
        <td>${new Date(entry.created_at).toLocaleDateString()}</td>
      </tr>
    `).join("");

    contentDiv.innerHTML = `
      <table>
        <thead>
          <tr><th>Company</th><th>Reason</th><th>Reports</th><th>Added</th></tr>
        </thead>
        <tbody>${rows}</tbody>
      </table>
    `;
  }

  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }
});