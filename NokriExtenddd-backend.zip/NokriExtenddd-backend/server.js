require('dotenv').config();

const express = require('express');
const cors = require('cors');
const { Pool, types } = require('pg');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const cron = require('node-cron');

// Postgres DATE columns (OID 1082) are returned as JS Date objects by default,
// which pg constructs at local midnight — converting that to JSON later shifts
// the date by your timezone offset. Deadlines don't need time-of-day precision,
// so we return the raw 'YYYY-MM-DD' string instead and skip that conversion entirely.
types.setTypeParser(1082, (val) => val);

const app = express();
app.use(cors());
app.use(express.json());

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'nokriextenddd',
  password: 'postgres',
  port: 5432,
});


// ===== AUTH: REGISTER =====

app.post('/register', async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: "Email and password are required" });
  }

  try {
    const passwordHash = await bcrypt.hash(password, 10);

    const result = await pool.query(
      `INSERT INTO users (email, password_hash) VALUES ($1, $2) RETURNING id, email, plan`,
      [email, passwordHash]
    );

    const newUser = result.rows[0];

    const token = jwt.sign(
      { userId: newUser.id, email: newUser.email },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.json({ token, user: { id: newUser.id, email: newUser.email, plan: newUser.plan } });
  } catch (err) {
    if (err.code === '23505') {
      return res.status(409).json({ error: "An account with this email already exists" });
    }
    console.error("Registration failed:", err);
    res.status(500).json({ error: "Registration failed" });
  }
});

// ===== AUTH: LOGIN =====

app.post('/login', async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: "Email and password are required" });
  }

  try {
    const result = await pool.query(
      `SELECT * FROM users WHERE email = $1`,
      [email]
    );

    if (result.rows.length === 0) {
      return res.status(401).json({ error: "Invalid email or password" });
    }

    const user = result.rows[0];
    const passwordMatches = await bcrypt.compare(password, user.password_hash);

    if (!passwordMatches) {
      return res.status(401).json({ error: "Invalid email or password" });
    }

    const token = jwt.sign(
      { userId: user.id, email: user.email },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.json({ token, user: { id: user.id, email: user.email, plan: user.plan } });
  } catch (err) {
    console.error("Login failed:", err);
    res.status(500).json({ error: "Login failed" });
  }
});

// ===== AUTH MIDDLEWARE =====

function requireAuth(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: "No token provided" });
  }

  const token = authHeader.split(' ')[1];

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(401).json({ error: "Invalid or expired token" });
  }
}

// ===== DASHBOARD (single, top-level route) =====

app.get('/dashboard', requireAuth, async (req, res) => {
  const userId = req.user.userId;

  try {
    const userResult = await pool.query(`SELECT plan FROM users WHERE id = $1`, [userId]);
    const userPlan = userResult.rows[0]?.plan || 'free';

    if (userPlan === 'free') {
      // Free tier: aggregate counts only, grouped by rough status
      const statsResult = await pool.query(
        `SELECT
           COUNT(*) AS total_screenings,
           COUNT(*) FILTER (WHERE score >= 60) AS high_risk_count,
           COUNT(*) FILTER (WHERE score >= 30 AND score < 60) AS caution_count,
           COUNT(*) FILTER (WHERE score < 30) AS likely_real_count
         FROM screenings
         WHERE user_id = $1`,
        [userId]
      );

      res.json({
        plan: 'free',
        stats: statsResult.rows[0]
      });
    } else {
      // Pro tier: full per-job history
      const historyResult = await pool.query(
        `SELECT id, job_title, company_name, score, flags, created_at
         FROM screenings
         WHERE user_id = $1
         ORDER BY created_at DESC`,
        [userId]
      );

      res.json({
        plan: 'pro',
        history: historyResult.rows
      });
    }
  } catch (err) {
    console.error("Dashboard fetch failed:", err);
    res.status(500).json({ error: "Failed to load dashboard" });
  }
});

// ===== SAVE JOB WITH DEADLINE =====

app.post('/save-job', requireAuth, async (req, res) => {
  const { job_title, company_name, deadline } = req.body;
  const userId = req.user.userId;

  if (!job_title || !deadline) {
    return res.status(400).json({ error: "job_title and deadline are required" });
  }

  try {
    await pool.query(
      `INSERT INTO saved_jobs (user_id, job_title, company_name, deadline)
       VALUES ($1, $2, $3, $4)`,
      [userId, job_title, company_name, deadline]
    );
    res.json({ message: "Job saved successfully" });
  } catch (err) {
    console.error("Failed to save job:", err);
    res.status(500).json({ error: "Failed to save job" });
  }
});

// ===== RULE-BASED SCORING (rule_checks portion of the formula) =====

function runRuleChecks(data) {
  let flags = [];
  let ruleScore = 0;

  if (!data.job_description) {
    flags.push("No job description found");
    ruleScore += 25;
  }

  const freeEmailPattern = /@(gmail|yahoo|hotmail|outlook)\.com/i;
  if (data.company_description && freeEmailPattern.test(data.company_description)) {
    flags.push("Company uses a free email domain instead of a corporate one");
    ruleScore += 30;
  }

  if (!data.company_name) {
    flags.push("No company name found");
    ruleScore += 20;
  }

  if (data.job_description && data.job_description.length < 80) {
    flags.push("Job description is unusually short");
    ruleScore += 15;
  }

  ruleScore = Math.min(ruleScore, 100);

  return { ruleScore, flags };
}

// ===== PREFERENCE MATCHING (FR4 — separate from fraud score) =====
// Compares scraped job fields against the user's saved preferences.
// Returns { checked: false } if the user hasn't set any preferences yet —
// in that case, nothing should be flagged.

function parseSalaryNumber(salaryText) {
  if (salaryText == null) return null;
  if (typeof salaryText === 'number') return salaryText;

  // Pulls the first number out of strings like "$40,000 - $50,000/yr" or "PKR 60,000/mo"
  // [VALIDATE] this is a best-effort parse — LinkedIn salary text formats vary a lot,
  // and this will misparse anything unusual. Fine for a same-day build, revisit later.
  const match = String(salaryText).replace(/,/g, '').match(/(\d+(\.\d+)?)/);
  return match ? parseFloat(match[1]) : null;
}

function checkPreferences(data, prefs) {
  if (!prefs) {
    return { checked: false };
  }

  const hasAnyPreference =
    prefs.preferred_department ||
    prefs.preferred_employment_type ||
    prefs.preferred_location ||
    prefs.min_salary != null;

  if (!hasAnyPreference) {
    return { checked: false };
  }

  const mismatches = [];

  if (prefs.preferred_department) {
    const wantDept = prefs.preferred_department.toLowerCase();
    const jobDept = (data.department || '').toLowerCase();
    const jobTitle = (data.job_title || '').toLowerCase();

    // LinkedIn often doesn't expose a distinct "department" field —
    // fall back to checking the job title, since department names
    // (e.g. "Marketing") usually show up there instead
    const matchesDept = jobDept.includes(wantDept) || jobTitle.includes(wantDept);

    if (!matchesDept) {
      mismatches.push(`Job title "${data.job_title || 'unspecified'}" does not mention your preferred department "${prefs.preferred_department}"`);
    }
  }

  if (prefs.preferred_employment_type) {
    const jobType = (data.employment_type || '').toLowerCase();
    const wantType = prefs.preferred_employment_type.toLowerCase();
    if (!jobType.includes(wantType)) {
      mismatches.push(`Employment type "${data.employment_type || 'unspecified'}" does not match your preferred "${prefs.preferred_employment_type}"`);
    }
  }

  if (prefs.preferred_location) {
    const wantLoc = prefs.preferred_location.toLowerCase();
    const jobLoc = (data.location || '').toLowerCase();
    const jobTitle = (data.job_title || '').toLowerCase();

    // Same issue as department — location sometimes isn't scraped separately,
    // but it's often mentioned right in the job title (e.g. "(Onsite, Lahore, PKR Salary)")
    const matchesLoc = jobLoc.includes(wantLoc) || jobTitle.includes(wantLoc);

    if (!matchesLoc) {
      mismatches.push(`Could not confirm location matches your preferred "${prefs.preferred_location}"`);
    }
  }

  if (prefs.min_salary != null) {
    const jobSalary = parseSalaryNumber(data.salary);
    if (jobSalary === null) {
      mismatches.push(`Could not determine salary from posting to compare against your minimum of ${prefs.min_salary}`);
    } else if (jobSalary < parseFloat(prefs.min_salary)) {
      mismatches.push(`Salary (${jobSalary}) is below your minimum of ${prefs.min_salary}`);
    }
  }

  return {
    checked: true,
    matches: mismatches.length === 0,
    mismatches
  };
}

// ===== SCORE ENDPOINT (protected — requires login) =====

app.post('/score', requireAuth, async (req, res) => {
  const data = req.body;

  if (!data || !data.job_title) {
    return res.status(400).json({ error: "Missing job data" });
  }

  const userId = req.user.userId;

  // ===== QUOTA CHECK =====
  try {
    const userResult = await pool.query(`SELECT plan FROM users WHERE id = $1`, [userId]);
    const userPlan = userResult.rows[0]?.plan || 'free';

    if (userPlan === 'free') {
      const countResult = await pool.query(
        `SELECT COUNT(*) FROM screenings
         WHERE user_id = $1
         AND created_at >= date_trunc('month', CURRENT_DATE)`,
        [userId]
      );
      const screeningsThisMonth = parseInt(countResult.rows[0].count, 10);

      if (screeningsThisMonth >= 70) {
        return res.status(403).json({
          error: "Monthly quota reached (200 screenings). Upgrade to Pro for unlimited screenings.",
          quotaReached: true
        });
      }
    }
  } catch (err) {
    console.error("Quota check failed:", err);
  }

  const { ruleScore, flags } = runRuleChecks(data);

  let ml_probability = 0;
  try {
    const flaskResponse = await fetch('http://localhost:5000/predict', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    const flaskResult = await flaskResponse.json();
    ml_probability = (flaskResult.fraud_probability || 0) * 100;
    console.log("ML probability received:", ml_probability);
  } catch (err) {
    console.error("Failed to reach ML model service:", err);
  }

  let blacklist_flag = 0;
  try {
    const blacklistResult = await pool.query(
      `SELECT * FROM blacklist WHERE LOWER(company_name) = LOWER($1)`,
      [data.company_name]
    );
    if (blacklistResult.rows.length > 0) {
      blacklist_flag = 100;
      flags.push(`Company "${data.company_name}" is on the blacklist: ${blacklistResult.rows[0].reason}`);
    }
  } catch (err) {
    console.error("Blacklist check failed:", err);
  }

  const w1 = 0.6, w2 = 0.3, w3 = 0.1;
  const finalScore = Math.round(
    (w1 * ml_probability) + (w2 * blacklist_flag) + (w3 * ruleScore)
  );

  // ===== PREFERENCE MATCH CHECK (FR4) — kept separate from finalScore/flags on purpose =====
  let preferenceMatch = { checked: false };
  try {
    const prefsResult = await pool.query(
      `SELECT id, label, preferred_department, preferred_employment_type, preferred_location, min_salary
       FROM preferences WHERE user_id = $1`,
      [userId]
    );

    if (prefsResult.rows.length === 0) {
      preferenceMatch = { checked: false };
    } else {
      // Check against every saved profile; the job "matches" if it satisfies ANY one of them
      const results = prefsResult.rows.map(profile => ({
        profileId: profile.id,
        label: profile.label,
        ...checkPreferences(data, profile)
      }));

      const matchedProfile = results.find(r => r.matches);

      preferenceMatch = {
        checked: true,
        matches: !!matchedProfile,
        matchedProfileLabel: matchedProfile ? matchedProfile.label : null,
        // If nothing matched, show the mismatches from the profile that came closest
        // (fewest mismatches), so the user gets a useful reason rather than a dump of everything
        mismatches: matchedProfile
          ? []
          : results.sort((a, b) => a.mismatches.length - b.mismatches.length)[0].mismatches
      };
    }
  } catch (err) {
    console.error("Preference check failed:", err);
  }

  try {
    await pool.query(
      `INSERT INTO screenings (user_id, job_title, company_name, score, flags)
       VALUES ($1, $2, $3, $4, $5)`,
      [userId, data.job_title, data.company_name, finalScore, JSON.stringify(flags)]
    );
    console.log("Screening saved successfully:", data.job_title);
  } catch (err) {
    console.error("Failed to save screening:", err);
  }

  res.json({
    score: finalScore,
    flags: flags,
    note: "Score reflects ML model + blacklist + rule_checks (beta model, trained on limited data)",
    preferenceMatch: preferenceMatch
  });
});

// ===== PREFERENCES (multiple profiles — Pro can have several, free limited to 1) =====

// List all of the user's preference profiles
app.get('/preferences', requireAuth, async (req, res) => {
  const userId = req.user.userId;

  try {
    const result = await pool.query(
      `SELECT id, label, preferred_department, preferred_employment_type, preferred_location, min_salary, created_at, updated_at
       FROM preferences WHERE user_id = $1 ORDER BY created_at ASC`,
      [userId]
    );
    res.json({ preferences: result.rows });
  } catch (err) {
    console.error("Failed to fetch preferences:", err);
    res.status(500).json({ error: "Failed to fetch preferences" });
  }
});

// Create a new preference profile
app.post('/preferences', requireAuth, async (req, res) => {
  const userId = req.user.userId;
  const { label, preferred_department, preferred_employment_type, preferred_location, min_salary } = req.body;

  try {
    const userResult = await pool.query(`SELECT plan FROM users WHERE id = $1`, [userId]);
    const userPlan = userResult.rows[0]?.plan || 'free';

    const countResult = await pool.query(`SELECT COUNT(*) FROM preferences WHERE user_id = $1`, [userId]);
    const existingCount = parseInt(countResult.rows[0].count, 10);

    const maxProfiles = userPlan === 'free' ? 1 : 10;

    if (existingCount >= maxProfiles) {
      return res.status(403).json({
        error: userPlan === 'free'
          ? "Free plan is limited to 1 preference profile. Upgrade to Pro to save up to 10."
          : "You've reached the maximum of 10 preference profiles.",
        upgradeRequired: userPlan === 'free'
      });
    }

    const result = await pool.query(
      `INSERT INTO preferences (user_id, label, preferred_department, preferred_employment_type, preferred_location, min_salary)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING *`,
      [userId, label || null, preferred_department || null, preferred_employment_type || null, preferred_location || null, min_salary || null]
    );

    res.json({ message: "Preference profile created", preferences: result.rows[0] });
  } catch (err) {
    console.error("Failed to create preferences:", err);
    res.status(500).json({ error: "Failed to create preferences" });
  }
});

// Update one specific preference profile (identified by its id)
app.put('/preferences/:id', requireAuth, async (req, res) => {
  const userId = req.user.userId;
  const prefId = req.params.id;
  const { label, preferred_department, preferred_employment_type, preferred_location, min_salary } = req.body;

  try {
    const result = await pool.query(
      `UPDATE preferences
       SET label = $1, preferred_department = $2, preferred_employment_type = $3,
           preferred_location = $4, min_salary = $5, updated_at = NOW()
       WHERE id = $6 AND user_id = $7
       RETURNING *`,
      [label || null, preferred_department || null, preferred_employment_type || null, preferred_location || null, min_salary || null, prefId, userId]
    );

    // WHERE ... AND user_id = $7 means a user can never update someone else's row —
    // if nothing matched, either the id doesn't exist or it isn't theirs
    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Preference profile not found" });
    }

    res.json({ message: "Preference profile updated", preferences: result.rows[0] });
  } catch (err) {
    console.error("Failed to update preferences:", err);
    res.status(500).json({ error: "Failed to update preferences" });
  }
});

// Delete one specific preference profile
app.delete('/preferences/:id', requireAuth, async (req, res) => {
  const userId = req.user.userId;
  const prefId = req.params.id;

  try {
    const result = await pool.query(
      `DELETE FROM preferences WHERE id = $1 AND user_id = $2 RETURNING id`,
      [prefId, userId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Preference profile not found" });
    }

    res.json({ message: "Preference profile deleted" });
  } catch (err) {
    console.error("Failed to delete preferences:", err);
    res.status(500).json({ error: "Failed to delete preferences" });
  }
});

// ===== BEHAVIOR LOGGING (for future retraining — not used yet) =====

app.post('/log-action', requireAuth, async (req, res) => {
  const { job_title, company_name, action } = req.body;
  const userId = req.user.userId;

  const validActions = ['applied', 'saved', 'flagged'];
  if (!action || !validActions.includes(action)) {
    return res.status(400).json({ error: "action must be one of: " + validActions.join(', ') });
  }

  try {
    await pool.query(
      `INSERT INTO behavior_logs (user_id, job_title, company_name, action)
       VALUES ($1, $2, $3, $4)`,
      [userId, job_title, company_name, action]
    );

    // "saved" additionally creates a row the deadline-reminder cron job can query
    if (action === 'saved') {
      await pool.query(
        `INSERT INTO saved_jobs (user_id, job_title, company_name, deadline, notified)
         VALUES ($1, $2, $3, NULL, false)`,
        [userId, job_title, company_name]
      );
    }

    res.json({ message: "Action logged" });
  } catch (err) {
    console.error("Failed to log action:", err);
    res.status(500).json({ error: "Failed to log action" });
  }
});

// ===== ACTIVITY SUMMARY (applied/saved counts, full detail for Pro) =====

app.get('/activity', requireAuth, async (req, res) => {
  const userId = req.user.userId;

  try {
    const userResult = await pool.query(`SELECT plan FROM users WHERE id = $1`, [userId]);
    const userPlan = userResult.rows[0]?.plan || 'free';

    const countsResult = await pool.query(
      `SELECT
         COUNT(*) FILTER (WHERE action = 'applied') AS applied_count,
         COUNT(*) FILTER (WHERE action = 'saved') AS saved_count
       FROM behavior_logs
       WHERE user_id = $1`,
      [userId]
    );

    const response = {
      plan: userPlan,
      appliedCount: parseInt(countsResult.rows[0].applied_count, 10),
      savedCount: parseInt(countsResult.rows[0].saved_count, 10)
    };

    // Free users only get the counts above — full per-job detail is Pro-only
    if (userPlan === 'pro') {
      const appliedResult = await pool.query(
        `SELECT job_title, company_name, created_at FROM behavior_logs
         WHERE user_id = $1 AND action = 'applied' ORDER BY created_at DESC`,
        [userId]
      );
      const savedResult = await pool.query(
        `SELECT job_title, company_name, created_at FROM behavior_logs
         WHERE user_id = $1 AND action = 'saved' ORDER BY created_at DESC`,
        [userId]
      );

      response.applied = appliedResult.rows;
      response.saved = savedResult.rows;
    }

    res.json(response);
  } catch (err) {
    console.error("Failed to fetch activity:", err);
    res.status(500).json({ error: "Failed to fetch activity" });
  }
});

// ===== DEADLINE REMINDER CRON JOB =====

cron.schedule('0 9 * * *', async () => {
  console.log("Running daily deadline check...");

  try {
    const result = await pool.query(
      `SELECT sj.id, sj.job_title, sj.company_name, sj.deadline, u.email
       FROM saved_jobs sj
       JOIN users u ON sj.user_id = u.id
       WHERE sj.deadline = CURRENT_DATE + INTERVAL '1 day'
       AND sj.notified = FALSE
       AND u.plan = 'pro'`
    );

    for (const job of result.rows) {
      // For now, we log the notification — real email/push delivery
      // is a separate integration to build later
      console.log(`REMINDER: ${job.email} — "${job.job_title}" at ${job.company_name} is due tomorrow (${job.deadline})`);

      await pool.query(
        `UPDATE saved_jobs SET notified = TRUE WHERE id = $1`,
        [job.id]
      );
    }

    console.log(`Deadline check complete. ${result.rows.length} reminder(s) processed.`);
  } catch (err) {
    console.error("Deadline check failed:", err);
  }
});

// ===== SAVED JOBS (list, set deadline, remove) =====

app.get('/saved-jobs', requireAuth, async (req, res) => {
  const userId = req.user.userId;

  try {
    const result = await pool.query(
      `SELECT id, job_title, company_name, deadline, notified, created_at
       FROM saved_jobs WHERE user_id = $1 ORDER BY
       (deadline IS NULL), deadline ASC, created_at DESC`,
      [userId]
    );
    res.json({ savedJobs: result.rows });
  } catch (err) {
    console.error("Failed to fetch saved jobs:", err);
    res.status(500).json({ error: "Failed to fetch saved jobs" });
  }
});

app.put('/saved-jobs/:id', requireAuth, async (req, res) => {
  const userId = req.user.userId;
  const jobId = req.params.id;
  const { deadline } = req.body;

  try {
    // Changing the deadline resets "notified" to false, so the cron job
    // will remind the user again if the new date lands on "tomorrow"
    const result = await pool.query(
      `UPDATE saved_jobs
       SET deadline = $1, notified = FALSE
       WHERE id = $2 AND user_id = $3
       RETURNING *`,
      [deadline || null, jobId, userId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Saved job not found" });
    }

    res.json({ message: "Deadline updated", savedJob: result.rows[0] });
  } catch (err) {
    console.error("Failed to update saved job:", err);
    res.status(500).json({ error: "Failed to update saved job" });
  }
});

app.delete('/saved-jobs/:id', requireAuth, async (req, res) => {
  const userId = req.user.userId;
  const jobId = req.params.id;

  try {
    const result = await pool.query(
      `DELETE FROM saved_jobs WHERE id = $1 AND user_id = $2 RETURNING id`,
      [jobId, userId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: "Saved job not found" });
    }

    res.json({ message: "Saved job removed" });
  } catch (err) {
    console.error("Failed to delete saved job:", err);
    res.status(500).json({ error: "Failed to delete saved job" });
  }
});

// ===== PUBLIC BLACKLIST (requires login — existing users only) =====

app.get('/blacklist', requireAuth, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT company_name, reason, flagged_count, created_at
       FROM blacklist
       WHERE approved_by IS NOT NULL
       ORDER BY created_at DESC`
    );
    res.json({ blacklist: result.rows });
  } catch (err) {
    console.error("Failed to fetch blacklist:", err);
    res.status(500).json({ error: "Failed to fetch blacklist" });
  }
});

// ===== CONTACT US (public — no login required) =====

app.post('/contact', async (req, res) => {
  const { name, email, message } = req.body;

  if (!email || !message) {
    return res.status(400).json({ error: "Email and message are required" });
  }

  try {
    await pool.query(
      `INSERT INTO contact_messages (name, email, message) VALUES ($1, $2, $3)`,
      [name || null, email, message]
    );

    // Real email delivery (e.g. Nodemailer) is a separate integration to add later —
    // for now, this matches the deadline-reminder pattern: log it, store it in Postgres.
    console.log(`New contact message from ${email}: ${message.slice(0, 80)}...`);

    res.json({ message: "Message received" });
  } catch (err) {
    console.error("Failed to save contact message:", err);
    res.status(500).json({ error: "Failed to send message" });
  }
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`NokriExtenddd API running on http://localhost:${PORT}`);
});